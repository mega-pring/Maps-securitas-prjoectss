import os
import random
import time
from datetime import datetime, timezone

import httpx

API_URL = os.getenv("API_URL", "http://localhost:8000")

HEL_BBOX = {
    "min_lat": 60.13,
    "max_lat": 60.25,
    "min_lon": 24.84,
    "max_lon": 25.05,
}


def rand_point():
    return {
        "lat": random.uniform(HEL_BBOX["min_lat"], HEL_BBOX["max_lat"]),
        "lon": random.uniform(HEL_BBOX["min_lon"], HEL_BBOX["max_lon"]),
    }


def register_vehicle(client, vehicle_id):
    client.post(f"{API_URL}/vehicles/register", json={"vehicle_id": vehicle_id, "mode": "PATROL_FUEL"})
    start = rand_point()
    client.post(
        f"{API_URL}/vehicles/{vehicle_id}/location",
        json={
            **start,
            "speed_mps": random.uniform(5, 12),
            "heading": random.uniform(0, 359),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        },
    )
    points = [rand_point() for _ in range(random.randint(20, 40))]
    client.post(f"{API_URL}/vehicles/{vehicle_id}/patrol", json={"points": points})


def simulate_calls(client, vehicle_ids):
    total_calls = len(vehicle_ids) * 2
    for i in range(total_calls):
        call_id = f"call-{i:04d}"
        call_pt = rand_point()
        client.post(f"{API_URL}/calls/create", json={"call_id": call_id, **call_pt, "priority": 2})
        assign = client.post(f"{API_URL}/calls/{call_id}/assign")
        if assign.status_code != 200:
            continue
        data = assign.json()
        vehicle_id = data["vehicle_id"]
        client.post(
            f"{API_URL}/vehicles/{vehicle_id}/location",
            json={
                **call_pt,
                "speed_mps": random.uniform(0, 5),
                "heading": random.uniform(0, 359),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        )
        client.post(f"{API_URL}/calls/{call_id}/complete", json={"vehicle_id": vehicle_id})
        time.sleep(0.05)


def main():
    random.seed(42)
    vehicle_ids = [f"veh-{i:03d}" for i in range(100)]
    with httpx.Client(timeout=20) as client:
        for vid in vehicle_ids:
            register_vehicle(client, vid)
        simulate_calls(client, vehicle_ids)
        metrics = client.get(f"{API_URL}/metrics/summary").json()
        print("Metrics:")
        for k, v in metrics.items():
            print(f"  {k}: {v}")


if __name__ == "__main__":
    main()