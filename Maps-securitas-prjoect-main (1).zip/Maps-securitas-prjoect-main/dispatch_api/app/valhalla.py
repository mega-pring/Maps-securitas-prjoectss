import time
from uuid import uuid4

import httpx
from tenacity import retry, stop_after_attempt, wait_fixed

from .config import settings


class ValhallaClient:
    def __init__(self) -> None:
        self.base_url = settings.valhalla_url.rstrip("/")
        self.timeout = settings.request_timeout_sec

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(0.2))
    def route(self, mode: str, from_pt: dict, to_pt: dict, alternates: int = 0) -> dict:
        payload = {
            "locations": [
                {"lat": from_pt["lat"], "lon": from_pt["lon"]},
                {"lat": to_pt["lat"], "lon": to_pt["lon"]},
            ],
            "costing": "auto",
            "directions_type": "maneuvers",
        }
        if alternates:
            payload["alternates"] = alternates
        if mode == "PATROL_FUEL":
            payload["costing_options"] = {
                "auto": {
                    "shortest": True,
                    "use_highways": 0.3,
                    "maneuver_penalty": 5,
                    "turn_penalty": 10,
                }
            }

        url = f"{self.base_url}/route"
        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(url, json=payload)
            resp.raise_for_status()
        data = resp.json()
        route_id = str(uuid4())
        data["_route_id"] = route_id
        data["_mode"] = mode
        data["_ts"] = int(time.time())
        return data
