import json
import logging
import time
from contextvars import ContextVar
from datetime import datetime, timezone
from uuid import uuid4

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from .algorithms import compute_disruption, rejoin_window_indices, route_summary, skip_penalty
from .config import settings
from .db import execute, fetch_all, fetch_one, init_db, insert_event
from .geocode import router as geocode_router
from .navigator import NavigatorService
from .navigator.api import router as navigator_router
from .navigator.profiles import TransportProfile
from .navigator.rerank import select_emergency, select_patrol_fuel
from .redis_state import RedisState
from .telemetry import router as telemetry_router
from .utils import grid_cell, haversine_km, neighbor_cells
from .valhalla import ValhallaClient

request_id_ctx: ContextVar[str] = ContextVar("request_id", default="-")


class RequestIdFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = request_id_ctx.get("-")
        return True


logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s %(levelname)s %(request_id)s %(message)s",
)
logger = logging.getLogger("dispatch")
logger.addFilter(RequestIdFilter())

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(geocode_router)
app.include_router(telemetry_router)
app.include_router(navigator_router)
redis_state = RedisState()
valhalla = ValhallaClient()
navigator = NavigatorService()


class VehicleRegister(BaseModel):
    vehicle_id: str
    mode: str = "PATROL_FUEL"


class LocationUpdate(BaseModel):
    lat: float
    lon: float
    speed_mps: float | None = None
    heading: float | None = None
    timestamp: str | None = None


class StatusUpdate(BaseModel):
    status: str


class PatrolPoint(BaseModel):
    lat: float
    lon: float


class PatrolUpload(BaseModel):
    points: list[PatrolPoint]


class CallCreate(BaseModel):
    call_id: str
    lat: float
    lon: float
    priority: int = 1


class CallComplete(BaseModel):
    vehicle_id: str


class PatrolAdvance(BaseModel):
    next_patrol_index: int


@app.middleware("http")
async def add_request_id(request, call_next):
    rid = request.headers.get("x-request-id", str(uuid4()))
    token = request_id_ctx.set(rid)
    try:
        response = await call_next(request)
        response.headers["x-request-id"] = rid
        return response
    finally:
        request_id_ctx.reset(token)


@app.on_event("startup")
def startup() -> None:
    init_db()


@app.get("/health")
@app.post("/health")
def health():
    return {"status": "ok"}


@app.post("/vehicles/register")
def register_vehicle(payload: VehicleRegister):
    execute(
        "INSERT INTO vehicles(id, mode) VALUES (%s, %s) "
        "ON CONFLICT (id) DO UPDATE SET mode = EXCLUDED.mode",
        (payload.vehicle_id, payload.mode),
    )
    redis_state.set_vehicle_state(payload.vehicle_id, 0.0, 0.0, "PATROLLING", payload.mode, 0)
    insert_event("vehicle_registered", payload.model_dump())
    return {"vehicle_id": payload.vehicle_id}


@app.post("/vehicles/{vehicle_id}/location")
def update_location(vehicle_id: str, payload: LocationUpdate):
    ts = payload.timestamp or datetime.now(timezone.utc).isoformat()
    execute(
        "INSERT INTO gps_points(vehicle_id, lat, lon, speed_mps, heading, ts) "
        "VALUES (%s,%s,%s,%s,%s,%s)",
        (vehicle_id, payload.lat, payload.lon, payload.speed_mps, payload.heading, ts),
    )
    redis_state.update_location(
        vehicle_id, payload.lat, payload.lon, payload.speed_mps, payload.heading, ts
    )
    insert_event(
        "vehicle_location", {"vehicle_id": vehicle_id, **payload.model_dump(), "timestamp": ts}
    )
    return {"ok": True}


@app.post("/vehicles/{vehicle_id}/status")
def update_status(vehicle_id: str, payload: StatusUpdate):
    execute("UPDATE vehicles SET status=%s WHERE id=%s", (payload.status, vehicle_id))
    redis_state.update_status(vehicle_id, payload.status)
    insert_event("vehicle_status", {"vehicle_id": vehicle_id, "status": payload.status})
    return {"ok": True}


@app.post("/vehicles/{vehicle_id}/patrol")
def upload_patrol(vehicle_id: str, payload: PatrolUpload):
    if len(payload.points) < 2:
        raise HTTPException(status_code=400, detail="patrol must have >=2 points")
    route_id = fetch_one(
        "INSERT INTO patrol_routes(vehicle_id) VALUES (%s) RETURNING id", (vehicle_id,)
    )[0]
    for idx, pt in enumerate(payload.points):
        execute(
            "INSERT INTO patrol_points(route_id, seq, lat, lon) VALUES (%s,%s,%s,%s)",
            (route_id, idx, pt.lat, pt.lon),
        )
    redis_state.update_next_patrol_index(vehicle_id, 0)
    insert_event("patrol_uploaded", {"vehicle_id": vehicle_id, "route_id": route_id})
    return {"route_id": route_id}


@app.post("/vehicles/{vehicle_id}/patrol/advance")
def advance_patrol(vehicle_id: str, payload: PatrolAdvance):
    redis_state.update_next_patrol_index(vehicle_id, payload.next_patrol_index)
    insert_event(
        "patrol_advance", {"vehicle_id": vehicle_id, "next_patrol_index": payload.next_patrol_index}
    )
    return {"ok": True}


@app.post("/calls/create")
def create_call(payload: CallCreate):
    execute(
        "INSERT INTO calls(id, lat, lon, priority) VALUES (%s,%s,%s,%s) "
        "ON CONFLICT (id) DO NOTHING",
        (payload.call_id, payload.lat, payload.lon, payload.priority),
    )
    insert_event("call_created", payload.model_dump())
    return {"call_id": payload.call_id}


@app.post("/calls/{call_id}/assign")
def assign_call(call_id: str):
    call = fetch_one("SELECT id, lat, lon, priority FROM calls WHERE id=%s", (call_id,))
    if not call:
        raise HTTPException(status_code=404, detail="call not found")
    _, call_lat, call_lon, _priority = call

    call_cell_id = grid_cell(call_lat, call_lon, settings.grid_km)
    redis_state.client.set(f"call_cell:{call_id}", call_cell_id, ex=3600)

    cells = neighbor_cells(call_cell_id)
    candidate_ids = redis_state.get_vehicles_in_cells(cells)
    if not candidate_ids:
        raise HTTPException(status_code=404, detail="no candidates")

    candidates = []
    now_ts = datetime.now(timezone.utc)
    for vid in candidate_ids:
        state = redis_state.get_vehicle(vid)
        if not state:
            continue
        status = state.get("status", "")
        if status not in {"PATROLLING", "AVAILABLE"}:
            continue
        last_ts = state.get("last_ts")
        if last_ts:
            age = now_ts - datetime.fromisoformat(last_ts.replace("Z", "+00:00"))
            if age.total_seconds() > settings.max_gps_age_sec:
                continue
        lat = float(state.get("lat", 0))
        lon = float(state.get("lon", 0))
        dist = haversine_km(lat, lon, call_lat, call_lon)
        candidates.append((vid, lat, lon, dist))

    candidates.sort(key=lambda x: x[3])
    candidates = candidates[: settings.candidates_n]

    candidates_scored = []
    traffic_version = navigator.traffic.traffic_version()
    vehicle_profile = TransportProfile()
    for vid, lat, lon, _dist in candidates:
        leg = navigator.get_leg_cost(
            "EMERGENCY_ETA",
            (lat, lon),
            (call_lat, call_lon),
            traffic_version,
            vehicle_profile,
            approximate=False,
        )
        eta = leg.eta_traffic
        rejoin_info = compute_rejoin_for_vehicle(vid, {"lat": call_lat, "lon": call_lon})
        disruption = compute_disruption(rejoin_info["extra_km"], rejoin_info["skip_penalty"])
        candidates_scored.append(
            {
                "vehicle_id": vid,
                "eta_traffic": eta,
                "route": get_or_compute_route(
                    "EMERGENCY_ETA",
                    {"lat": lat, "lon": lon},
                    {"lat": call_lat, "lon": call_lon},
                ),
                "disruption": disruption,
                "extra_km": rejoin_info["extra_km"],
            }
        )

    best = select_emergency(candidates_scored)
    if not best:
        raise HTTPException(status_code=404, detail="no viable candidates")

    route_id = best["route"].get("_route_id")
    execute(
        "INSERT INTO assignments(call_id, vehicle_id, eta_seconds, disruption, extra_km, route_id) "
        "VALUES (%s,%s,%s,%s,%s,%s)",
        (
            call_id,
            best["vehicle_id"],
            best["eta_traffic"],
            best["disruption"],
            best["extra_km"],
            route_id,
        ),
    )
    execute("UPDATE calls SET status='ASSIGNED' WHERE id=%s", (call_id,))
    execute("UPDATE vehicles SET status='EMERGENCY' WHERE id=%s", (best["vehicle_id"],))
    redis_state.update_status(best["vehicle_id"], "EMERGENCY")
    execute("UPDATE vehicles SET mode='EMERGENCY_ETA' WHERE id=%s", (best["vehicle_id"],))
    redis_state.update_mode(best["vehicle_id"], "EMERGENCY_ETA")
    redis_state.set_active_route(best["vehicle_id"], route_id)
    redis_state.set_route_payload(route_id, best["route"], ttl_sec=3600)
    insert_event(
        "call_assigned",
        {"call_id": call_id, "vehicle_id": best["vehicle_id"], "eta": best["eta_traffic"]},
    )

    return {
        "vehicle_id": best["vehicle_id"],
        "eta_seconds": best["eta_traffic"],
        "route_id": route_id,
    }


@app.post("/calls/{call_id}/complete")
def complete_call(call_id: str, payload: CallComplete):
    execute("UPDATE calls SET status='COMPLETED' WHERE id=%s", (call_id,))
    execute(
        "UPDATE assignments SET completed_at=NOW() WHERE call_id=%s AND vehicle_id=%s",
        (call_id, payload.vehicle_id),
    )
    execute("UPDATE vehicles SET status='RETURNING' WHERE id=%s", (payload.vehicle_id,))
    redis_state.update_status(payload.vehicle_id, "RETURNING")
    execute("UPDATE vehicles SET mode='PATROL_FUEL' WHERE id=%s", (payload.vehicle_id,))
    redis_state.update_mode(payload.vehicle_id, "PATROL_FUEL")
    vehicle_state = redis_state.get_vehicle(payload.vehicle_id)
    if not vehicle_state:
        raise HTTPException(status_code=404, detail="vehicle not found in redis")
    lat = float(vehicle_state.get("lat", 0))
    lon = float(vehicle_state.get("lon", 0))

    rejoin_info = compute_rejoin_for_vehicle(
        payload.vehicle_id, {"lat": lat, "lon": lon}, apply_update=True
    )

    insert_event(
        "call_completed",
        {"call_id": call_id, "vehicle_id": payload.vehicle_id, **rejoin_info},
    )

    return {
        "route_id": rejoin_info["route_id"],
        "next_patrol_index": rejoin_info["next_patrol_index"],
    }


@app.get("/vehicles/{vehicle_id}/route")
def get_vehicle_route(vehicle_id: str):
    state = redis_state.get_vehicle(vehicle_id)
    if not state:
        raise HTTPException(status_code=404, detail="vehicle not found")
    route_id = state.get("active_route_id")
    if not route_id:
        raise HTTPException(status_code=404, detail="no active route")
    payload = redis_state.get_route_payload(route_id)
    if not payload:
        raise HTTPException(status_code=404, detail="route not cached")
    summary = route_summary(payload)
    return {
        "route_id": route_id,
        "mode": payload.get("_mode"),
        "shape": summary.get("shape"),
        "summary": {"time": summary["time_sec"], "length_km": summary["length_km"]},
    }


@app.get("/vehicles/{vehicle_id}/patrol/route")
def get_patrol_route(vehicle_id: str):
    state = redis_state.get_vehicle(vehicle_id)
    if not state:
        raise HTTPException(status_code=404, detail="vehicle not found")
    lat = float(state.get("lat", 0))
    lon = float(state.get("lon", 0))
    next_index = int(state.get("next_patrol_index", 0))

    route_row = fetch_one(
        "SELECT id FROM patrol_routes WHERE vehicle_id=%s ORDER BY created_at DESC LIMIT 1",
        (vehicle_id,),
    )
    if not route_row:
        raise HTTPException(status_code=404, detail="no patrol route")
    route_id = route_row[0]
    point = fetch_one(
        "SELECT seq, lat, lon FROM patrol_points WHERE route_id=%s AND seq=%s",
        (route_id, next_index),
    )
    if not point:
        raise HTTPException(status_code=404, detail="patrol point not found")
    _seq, p_lat, p_lon = point
    route = get_or_compute_route(
        "PATROL_FUEL", {"lat": lat, "lon": lon}, {"lat": p_lat, "lon": p_lon}
    )
    rid = route.get("_route_id")
    redis_state.set_active_route(vehicle_id, rid)
    redis_state.set_route_payload(rid, route, ttl_sec=3600)
    return {"route_id": rid}


@app.get("/metrics/summary")
def metrics_summary():
    stats = fetch_one(
        "SELECT AVG(eta_seconds), PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY eta_seconds), "
        "AVG(extra_km), AVG(disruption) FROM assignments"
    )
    avg_eta, p95_eta, avg_extra_km, avg_disruption = stats if stats else (0, 0, 0, 0)
    fuel_sum = fetch_one(
        "SELECT COALESCE(SUM((payload->>'fuel_score')::float),0) "
        "FROM events WHERE type='fuel_score'"
    )
    fuel_score_sum = fuel_sum[0] if fuel_sum else 0
    return {
        "avg_eta": int(avg_eta or 0),
        "p95_eta": int(p95_eta or 0),
        "avg_extra_km": float(avg_extra_km or 0),
        "fuel_score_sum": float(fuel_score_sum or 0),
        "avg_disruption": float(avg_disruption or 0),
    }


@app.get("/metrics/navigator")
def metrics_navigator():
    rows = fetch_all(
        "SELECT payload FROM events WHERE type IN ('navigator_route_built','patrol_plan_built')"
    )
    total_fuel = 0.0
    total_eta = 0.0
    count = 0
    for r in rows:
        payload = r[0]
        if isinstance(payload, dict):
            if "fuel" in payload:
                total_fuel += float(payload.get("fuel", 0))
            if "eta" in payload:
                total_eta += float(payload.get("eta", 0))
        count += 1
    return {"count": count, "fuel_total": total_fuel, "eta_total": total_eta}


@app.get("/telemetry/vehicles")
def telemetry_vehicles():
    ids = redis_state.get_all_vehicle_ids()
    items = []
    for vid in ids:
        state = redis_state.get_vehicle(vid)
        if not state:
            continue
        state["vehicle_id"] = vid
        items.append(state)
    return items


@app.get("/telemetry/calls")
def telemetry_calls():
    rows = fetch_all("SELECT id, lat, lon, status FROM calls WHERE status IN ('OPEN','ASSIGNED')")
    return [{"call_id": r[0], "lat": r[1], "lon": r[2], "status": r[3]} for r in rows]


def get_or_compute_route(mode: str, from_pt: dict, to_pt: dict) -> dict:
    bucket = int(time.time() / settings.route_cache_bucket_sec)
    key = (
        f"{mode}:{from_pt['lat']:.5f},{from_pt['lon']:.5f}:"
        f"{to_pt['lat']:.5f},{to_pt['lon']:.5f}:{bucket}"
    )
    cached = redis_state.get_cached_route(key)
    if cached:
        return cached
    route = valhalla.route(mode, from_pt, to_pt)
    redis_state.cache_route(key, route, settings.route_cache_ttl_sec)
    execute(
        "INSERT INTO routes_cache(key, payload, ttl_sec) VALUES (%s,%s,%s) "
        "ON CONFLICT (key) DO UPDATE SET payload=EXCLUDED.payload, "
        "ttl_sec=EXCLUDED.ttl_sec, created_at=NOW()",
        (key, json.dumps(route), settings.route_cache_ttl_sec),
    )
    return route


def compute_rejoin_for_vehicle(vehicle_id: str, start_pt: dict, apply_update: bool = False) -> dict:
    route_id = fetch_one(
        "SELECT id FROM patrol_routes WHERE vehicle_id=%s ORDER BY created_at DESC LIMIT 1",
        (vehicle_id,),
    )
    if not route_id:
        raise HTTPException(status_code=404, detail="no patrol route")

    route_id = route_id[0]
    points = fetch_all(
        "SELECT seq, lat, lon FROM patrol_points WHERE route_id=%s ORDER BY seq ASC",
        (route_id,),
    )
    if not points:
        raise HTTPException(status_code=404, detail="no patrol points")

    state = redis_state.get_vehicle(vehicle_id)
    next_index = int(state.get("next_patrol_index", 0)) if state else 0

    max_index = len(points) - 1
    if next_index > max_index:
        next_index = max_index
    candidate_indices = rejoin_window_indices(next_index, max_index)

    candidates_scored = []
    traffic_version = navigator.traffic.traffic_version()
    vehicle_profile = TransportProfile()
    legs = []
    for idx in candidate_indices:
        _seq, lat, lon = points[idx]
        leg = navigator.get_leg_cost(
            "PATROL_FUEL",
            (start_pt["lat"], start_pt["lon"]),
            (lat, lon),
            traffic_version,
            vehicle_profile,
            approximate=False,
        )
        legs.append((idx, lat, lon, leg))

    best_eta = min((l[3].eta_traffic for l in legs), default=0.0)
    for idx, lat, lon, leg in legs:
        skip_pen = skip_penalty(next_index, idx)
        candidates_scored.append(
            {
                "next_patrol_index": idx,
                "extra_km": leg.length_km,
                "skip_penalty": skip_pen,
                "eta_traffic": leg.eta_traffic,
                "fuel_cost": leg.fuel_cost_total,
                "route": None,
                "route_id": None,
                "lat": lat,
                "lon": lon,
            }
        )

    best = select_patrol_fuel(
        candidates_scored,
        best_eta,
        settings.fuel_max_detour_pct,
        settings.fuel_eta_tradeoff_k,
    )

    if not best:
        raise HTTPException(status_code=500, detail="rejoin selection failed")

    if best["route"] is None:
        best["route"] = get_or_compute_route(
            "PATROL_FUEL", start_pt, {"lat": best["lat"], "lon": best["lon"]}
        )
        best["route_id"] = best["route"].get("_route_id")

    if apply_update:
        redis_state.update_next_patrol_index(vehicle_id, best["next_patrol_index"])
        redis_state.set_active_route(vehicle_id, best["route_id"])
        redis_state.set_route_payload(best["route_id"], best["route"], ttl_sec=3600)
        insert_event("fuel_score", {"vehicle_id": vehicle_id, "fuel_score": best["score"]})

    return best
