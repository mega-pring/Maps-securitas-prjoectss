from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import datetime, timezone

from ..config import settings
from ..db import insert_event
from .constraints import TimeWindow, late_penalty, priority_penalty
from .cost import eta_freeflow, eta_traffic, fuel_cost, route_summary
from .local_search import TaskNode, local_search, schedule_and_cost
from .profiles import TransportProfile
from .service import NavigatorService


@dataclass
class Task:
    id: str
    lat: float
    lon: float
    priority: int = 1
    service_time_sec: int = 0
    time_window: TimeWindow | None = None
    hard_window: bool = False


def _task_node(task: Task) -> TaskNode:
    return TaskNode(
        id=task.id,
        lat=task.lat,
        lon=task.lon,
        priority=task.priority,
        service_time_sec=task.service_time_sec,
        time_window=task.time_window,
    )


def approximate_plan_cost(
    get_leg_cost, mode: str, start: TaskNode, plan: list[TaskNode], start_ts: float
) -> float:
    total = 0.0
    cur = start
    ts = start_ts
    for idx, t in enumerate(plan):
        leg = get_leg_cost(mode, (cur.lat, cur.lon), (t.lat, t.lon), approximate=True)
        ts += leg.eta_traffic
        total += leg.fuel_cost_total + priority_penalty(t.priority, idx) + late_penalty(
            ts, t.time_window
        )
        ts += t.service_time_sec
        cur = t
    return total


def greedy_insertion(
    tasks: list[Task],
    start: tuple[float, float],
    get_leg_cost,
    mode: str,
    start_ts: float,
) -> list[Task]:
    remaining = tasks[:]
    remaining.sort(key=lambda t: (not t.hard_window, -t.priority))
    plan: list[Task] = []
    for t in remaining:
        best_pos = 0
        best_cost = None
        for pos in range(len(plan) + 1):
            cand = plan[:]
            cand.insert(pos, t)
            cand_nodes = [_task_node(x) for x in cand]
            cost = approximate_plan_cost(
                get_leg_cost,
                mode,
                TaskNode("start", start[0], start[1], 1, 0, None),
                cand_nodes,
                start_ts,
            )
            if best_cost is None or cost < best_cost:
                best_cost = cost
                best_pos = pos
        plan.insert(best_pos, t)
    return plan


def build_plan(
    tasks: list[Task],
    start: tuple[float, float],
    optimize_order: bool,
    vehicle: TransportProfile,
    mode: str,
    options: dict | None = None,
) -> dict:
    if not tasks:
        return {"order": [], "schedule": [], "totals": {}, "legs": []}

    options = options or {}
    max_tasks = int(options.get("max_tasks", 0) or 0)
    if max_tasks > 0:
        tasks = tasks[:max_tasks]

    service = NavigatorService()
    traffic_version = service.traffic.traffic_version()

    def get_leg_cost(
        mode_arg: str, a: tuple[float, float], b: tuple[float, float], approximate: bool = False
    ):
        return service.get_leg_cost(
            mode_arg, a, b, traffic_version, vehicle, approximate=approximate
        )

    start_node = TaskNode(
        id="start",
        lat=start[0],
        lon=start[1],
        priority=1,
        service_time_sec=0,
        time_window=None,
    )
    start_ts = time.time()

    if optimize_order:
        plan = greedy_insertion(tasks, start, get_leg_cost, mode, start_ts)
        nodes = [_task_node(t) for t in plan]
        nodes = local_search(
            get_leg_cost,
            mode,
            start_node,
            nodes,
            start_ts,
            time_budget_ms=int(options.get("time_budget_ms", 0) or 0) or None,
            max_iters=int(options.get("local_search_iters", 0) or 0) or None,
        )
        id_map = {t.id: t for t in plan}
        plan = [id_map[n.id] for n in nodes]
    else:
        plan = tasks

    totals = {
        "fuel_cost": 0.0,
        "eta_total_sec_traffic": 0.0,
        "late_penalty": 0.0,
        "miss_penalty": 0.0,
    }
    schedule = []
    legs = []
    cur = start
    arrival_ts = start_ts

    nodes = [_task_node(t) for t in plan]
    sched = schedule_and_cost(get_leg_cost, mode, start_node, nodes, start_ts)
    if sched["late"] >= settings.hard_window_inf_penalty:
        insert_event("patrol_plan_infeasible", {"reason": "hard_window"})
        raise ValueError("infeasible_hard_window")

    for idx, t in enumerate(plan):
        route = service.route(
            mode,
            {"lat": cur[0], "lon": cur[1]},
            {"lat": t.lat, "lon": t.lon},
            alternates=1,
        )
        traffic_info = service.traffic.annotate_route(_shape_points(route), time.time())
        fuel = fuel_cost(route, traffic_info, vehicle)
        eta = eta_traffic(eta_freeflow(route), traffic_info)
        arrival_ts += eta
        late = late_penalty(arrival_ts, t.time_window)
        if late >= settings.hard_window_inf_penalty:
            insert_event("patrol_plan_infeasible", {"task": t.id})
            raise ValueError("infeasible_hard_window")
        totals["fuel_cost"] += fuel.total
        totals["eta_total_sec_traffic"] += eta
        totals["late_penalty"] += late
        schedule.append(
            {
                "id": t.id,
                "eta_arrival_traffic_sec": eta,
                "arrival_ts": datetime.fromtimestamp(arrival_ts, tz=timezone.utc).isoformat(),
                "late_sec": max(
                    0, arrival_ts - (t.time_window.close_ts if t.time_window else arrival_ts)
                ),
                "window_ok": late == 0,
            }
        )
        legs.append(
            {
                "from": {"lat": cur[0], "lon": cur[1]},
                "to": {"lat": t.lat, "lon": t.lon},
                "route": {
                    "summary": route_summary(route),
                    "shape": route.get("trip", {}).get("legs", [{}])[0].get("shape"),
                    "fuel_cost": fuel.__dict__,
                    "eta_traffic_sec": eta,
                },
            }
        )
        arrival_ts += t.service_time_sec
        cur = (t.lat, t.lon)

    insert_event("patrol_plan_built", {"order": [t.id for t in plan], "totals": totals})
    return {"order": [t.id for t in plan], "schedule": schedule, "totals": totals, "legs": legs}


def _decode_polyline(encoded: str, precision: int = 6) -> list[tuple[float, float]]:
    coords: list[tuple[float, float]] = []
    index = 0
    lat = 0
    lon = 0
    factor = 10 ** precision
    while index < len(encoded):
        shift = 0
        result = 0
        while True:
            b = ord(encoded[index]) - 63
            index += 1
            result |= (b & 0x1F) << shift
            shift += 5
            if b < 0x20:
                break
        dlat = ~(result >> 1) if result & 1 else result >> 1
        lat += dlat
        shift = 0
        result = 0
        while True:
            b = ord(encoded[index]) - 63
            index += 1
            result |= (b & 0x1F) << shift
            shift += 5
            if b < 0x20:
                break
        dlon = ~(result >> 1) if result & 1 else result >> 1
        lon += dlon
        coords.append((lat / factor, lon / factor))
    return coords


def _shape_points(route: dict) -> list[tuple[float, float]]:
    trip = route.get("trip", {})
    legs = trip.get("legs", [])
    if not legs:
        return []
    shape = legs[0].get("shape")
    if isinstance(shape, list):
        return [(p[0], p[1]) for p in shape]
    if isinstance(shape, str):
        return _decode_polyline(shape, precision=6)
    return []
