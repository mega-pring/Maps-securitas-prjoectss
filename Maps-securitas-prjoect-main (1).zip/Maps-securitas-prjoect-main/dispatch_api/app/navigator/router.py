from __future__ import annotations

from ..valhalla import ValhallaClient
from .profiles import ModeProfile


def route(
    mode: str, from_pt: dict, to_pt: dict, options: dict | None = None, alternates: int = 0
) -> dict:
    _ = options or {}
    valhalla = ValhallaClient()
    return valhalla.route(mode, from_pt, to_pt, alternates=alternates)


def route_profile(
    profile: ModeProfile,
    from_pt: dict,
    to_pt: dict,
    options: dict | None = None,
    alternates: int = 0,
) -> dict:
    return route(profile.name, from_pt, to_pt, options=options, alternates=alternates)
