from __future__ import annotations

import time
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ..config import settings
from ..db import insert_event
from ..geocode import geocode_search
from .constraints import TimeWindow, parse_iso
from .cost import eta_freeflow, eta_traffic, fuel_cost
from .patrol_optimizer import Task, build_plan
from .profiles import TransportProfile
from .service import NavigatorService

router = APIRouter(prefix="/navigator")


class Coord(BaseModel):
    lat: float
    lon: float


class TaskIn(BaseModel):
    id: str
    lat: float | None = None
    lon: float | None = None
    address: str | None = None
    priority: int = 1
    service_time_sec: int = 0
    time_window: dict | None = None
    hard_window: bool = False


class PatrolOptimizeRequest(BaseModel):
    mode: str = "PATROL_FUEL"
    start: Coord | dict
    tasks: list[TaskIn]
    options: dict = Field(default_factory=dict)
    vehicle: dict | None = None


class RouteRequest(BaseModel):
    mode: str = "PATROL_FUEL"
    start: Coord | dict
    end: Coord | dict
    alternates: int = 1


def _resolve_point(obj: dict | Coord) -> Coord:
    if isinstance(obj, Coord):
        return obj
    if "lat" in obj and "lon" in obj:
        return Coord(lat=float(obj["lat"]), lon=float(obj["lon"]))
    if "address" in obj:
        res = geocode_search(obj["address"])
        results = res.get("results", [])
        if not results:
            raise HTTPException(status_code=404, detail="address_not_found")
        return Coord(lat=results[0]["lat"], lon=results[0]["lon"])
    raise HTTPException(status_code=400, detail="invalid_point")


@router.post("/route")
def navigator_route(req: RouteRequest) -> Any:
    start = _resolve_point(req.start)
    end = _resolve_point(req.end)
    service = NavigatorService()
    route = service.route(
        req.mode,
        {"lat": start.lat, "lon": start.lon},
        {"lat": end.lat, "lon": end.lon},
        alternates=req.alternates,
    )
    traffic_info = service.traffic.annotate_route(_shape_points(route), time.time())
    eta = eta_traffic(eta_freeflow(route), traffic_info)
    fuel = fuel_cost(route, traffic_info, TransportProfile())
    insert_event("navigator_route_built", {"mode": req.mode, "eta": eta, "fuel": fuel.total})
    return {
        "route": route,
        "eta_traffic_sec": eta,
        "fuel_cost": fuel.__dict__,
        "traffic": traffic_info,
    }


@router.post("/patrol/optimize")
def patrol_optimize(req: PatrolOptimizeRequest) -> Any:
    start = _resolve_point(req.start)
    tasks: list[Task] = []
    for t in req.tasks:
        if t.address:
            res = geocode_search(t.address)
            results = res.get("results", [])
            if not results:
                raise HTTPException(status_code=404, detail=f"address_not_found:{t.id}")
            lat = results[0]["lat"]
            lon = results[0]["lon"]
        else:
            if t.lat is None or t.lon is None:
                raise HTTPException(status_code=400, detail=f"missing_coords:{t.id}")
            lat, lon = t.lat, t.lon
        tw = None
        if t.time_window:
            open_ts = parse_iso(t.time_window.get("open"))
            close_ts = parse_iso(t.time_window.get("close"))
            if open_ts is not None and close_ts is not None:
                tw = TimeWindow(open_ts=open_ts, close_ts=close_ts, hard=t.hard_window)
        tasks.append(
            Task(
                id=t.id,
                lat=float(lat),
                lon=float(lon),
                priority=t.priority,
                service_time_sec=t.service_time_sec,
                time_window=tw,
                hard_window=t.hard_window,
            )
        )

    vehicle = TransportProfile(
        mass_kg=float((req.vehicle or {}).get("mass_kg", settings.mass_ref_kg)),
        eco_bias=float((req.vehicle or {}).get("eco_bias", 1.0)),
    )

    options = req.options or {}
    optimize_order = bool(options.get("optimize_order", False))
    try:
        plan = build_plan(tasks, (start.lat, start.lon), optimize_order, vehicle, req.mode, options)
    except ValueError:
        raise HTTPException(status_code=409, detail="infeasible_hard_window")
    return {
        "plan": {
            "order": plan["order"],
            "schedule": plan["schedule"],
            "totals": plan["totals"],
        },
        "legs": plan["legs"],
        "debug": {"algorithm": "greedy+local_search+window_repair", "coeffs": _coeffs()},
    }


def _coeffs() -> dict:
    return {
        "alpha_distance_m": settings.alpha_distance_m,
        "beta_turn_count": settings.beta_turn_count,
        "gamma_stopandgo": settings.gamma_stopandgo,
        "delta_urban": settings.delta_urban,
        "epsilon_traffic": settings.epsilon_traffic,
        "late_coeff": settings.late_coeff,
        "miss_coeff": settings.miss_coeff,
        "priority_mode": settings.priority_mode,
    }


def _shape_points(route: dict) -> list[tuple[float, float]]:
    trip = route.get("trip", {})
    legs = trip.get("legs", [])
    if not legs:
        return []
    shape = legs[0].get("shape")
    if isinstance(shape, list):
        return [(p[0], p[1]) for p in shape]
    if isinstance(shape, str):
        return _decode_polyline(shape, precision=6)
    return []


def _decode_polyline(encoded: str, precision: int = 6) -> list[tuple[float, float]]:
    coords: list[tuple[float, float]] = []
    index = 0
    lat = 0
    lon = 0
    factor = 10 ** precision
    while index < len(encoded):
        shift = 0
        result = 0
        while True:
            b = ord(encoded[index]) - 63
            index += 1
            result |= (b & 0x1F) << shift
            shift += 5
            if b < 0x20:
                break
        dlat = ~(result >> 1) if result & 1 else result >> 1
        lat += dlat
        shift = 0
        result = 0
        while True:
            b = ord(encoded[index]) - 63
            index += 1
            result |= (b & 0x1F) << shift
            shift += 5
            if b < 0x20:
                break
        dlon = ~(result >> 1) if result & 1 else result >> 1
        lon += dlon
        coords.append((lat / factor, lon / factor))
    return coords
