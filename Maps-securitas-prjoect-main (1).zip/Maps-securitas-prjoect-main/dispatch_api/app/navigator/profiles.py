from dataclasses import dataclass


@dataclass(frozen=True)
class TransportProfile:
    mass_kg: float = 1600.0
    eco_bias: float = 1.0
    avoid_highways: bool = False
    avoid_ferries: bool = True


@dataclass(frozen=True)
class ModeProfile:
    name: str
    optimize_for: str  # fuel or eta
    use_highways: float | None = None
    turn_penalty: float | None = None
    maneuver_penalty: float | None = None


PATROL_FUEL_PROFILE = ModeProfile(
    name="PATROL_FUEL",
    optimize_for="fuel",
    use_highways=0.3,
    turn_penalty=10,
    maneuver_penalty=5,
)

EMERGENCY_ETA_PROFILE = ModeProfile(
    name="EMERGENCY_ETA",
    optimize_for="eta",
    use_highways=1.0,
    turn_penalty=0,
    maneuver_penalty=0,
)