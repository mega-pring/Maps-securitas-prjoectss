import json
import time
from urllib.parse import urlparse

import httpx

from ...config import settings
from ...redis_state import RedisState


class DigitrafficClient:
    def __init__(self, redis_state: RedisState) -> None:
        self.redis = redis_state
        self.base_url = settings.traffic_base_url.rstrip("/")

    def _validate_base_url(self) -> None:
        parsed = urlparse(self.base_url)
        if parsed.scheme != "https":
            raise ValueError("digitraffic base url must be https")
        if parsed.netloc not in {"tie.digitraffic.fi"}:
            raise ValueError("digitraffic base url not allowed")

    def _rate_limit(self) -> None:
        key = "digitraffic:ratelimit"
        now = time.monotonic()
        last = self.redis.client.get(key)
        min_interval = 1.0 / max(0.1, settings.traffic_rps)
        if last and now - float(last) < min_interval:
            raise RuntimeError("digitraffic_rate_limited")
        self.redis.client.setex(key, 2, str(now))

    def fetch_stations(self) -> dict:
        cache_key = "digitraffic:stations"
        cached = self.redis.client.get(cache_key)
        if cached:
            return json.loads(cached)
        self._validate_base_url()
        self._rate_limit()
        url = f"{self.base_url}/api/tms/v1/stations/data"
        headers = {
            "User-Agent": settings.nominatim_user_agent,
            "Digitraffic-User": settings.digitraffic_user,
        }
        with httpx.Client(timeout=6) as client:
            try:
                resp = client.get(url, headers=headers)
                resp.raise_for_status()
            except Exception:
                resp = client.get(url, headers=headers)
                resp.raise_for_status()
        data = resp.json()
        self.redis.client.setex(cache_key, settings.traffic_cache_ttl_sec, json.dumps(data))
        return data
