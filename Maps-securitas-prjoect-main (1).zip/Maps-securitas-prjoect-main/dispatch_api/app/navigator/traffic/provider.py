from __future__ import annotations

import math
from abc import ABC, abstractmethod

from ...config import settings
from ...redis_state import RedisState
from .digitraffic_client import DigitrafficClient
from .normalizer import extract_traffic_version, normalize_snapshot
from .snapshot import cell_factor


class TrafficProvider(ABC):
    @abstractmethod
    def annotate_route(self, shape_points: list[tuple[float, float]], ts: float) -> dict:
        raise NotImplementedError

    @abstractmethod
    def traffic_version(self) -> str:
        raise NotImplementedError


class DigitrafficProvider(TrafficProvider):
    def __init__(self, redis_state: RedisState) -> None:
        self.redis = redis_state
        self.client = DigitrafficClient(redis_state)

    def annotate_route(self, shape_points: list[tuple[float, float]], ts: float) -> dict:
        snapshot = self.client.fetch_stations()
        stations = normalize_snapshot(snapshot)
        version = extract_traffic_version(snapshot)
        if not shape_points:
            return {"avg_factor": 1.0, "congested_share": 0.0, "traffic_version": version}
        sample = shape_points[:: max(1, len(shape_points)//30) or 1]
        factors = [cell_factor(p[0], p[1], stations) for p in sample]
        avg = sum(factors) / max(1, len(factors))
        congested = sum(1 for f in factors if f < 0.8) / max(1, len(factors))
        return {
            "avg_factor": max(0.3, min(1.3, avg)),
            "congested_share": congested,
            "traffic_version": version,
        }

    def traffic_version(self) -> str:
        snapshot = self.client.fetch_stations()
        return extract_traffic_version(snapshot)


class SyntheticProvider(TrafficProvider):
    def annotate_route(self, shape_points: list[tuple[float, float]], ts: float) -> dict:
        if not shape_points:
            return {"avg_factor": 1.0, "congested_share": 0.0, "traffic_version": "synthetic"}
        factors = []
        for p in shape_points[:: max(1, len(shape_points)//30) or 1]:
            lat, lon = p
            wave = math.sin((ts / 3600.0 + lat + lon) * 0.1) * 0.1
            factors.append(max(0.3, min(1.3, 1.0 + wave)))
        avg = sum(factors) / max(1, len(factors))
        congested = sum(1 for f in factors if f < 0.8) / max(1, len(factors))
        return {"avg_factor": avg, "congested_share": congested, "traffic_version": "synthetic"}

    def traffic_version(self) -> str:
        return "synthetic"


class ResilientProvider(TrafficProvider):
    def __init__(self, primary: TrafficProvider, fallback: TrafficProvider) -> None:
        self.primary = primary
        self.fallback = fallback

    def annotate_route(self, shape_points: list[tuple[float, float]], ts: float) -> dict:
        try:
            return self.primary.annotate_route(shape_points, ts)
        except Exception:
            return self.fallback.annotate_route(shape_points, ts)

    def traffic_version(self) -> str:
        try:
            return self.primary.traffic_version()
        except Exception:
            return self.fallback.traffic_version()


def get_traffic_provider() -> TrafficProvider:
    if settings.traffic_provider.lower() == "synthetic":
        return SyntheticProvider()
    return ResilientProvider(DigitrafficProvider(RedisState()), SyntheticProvider())
