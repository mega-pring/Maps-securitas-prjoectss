from __future__ import annotations

import json
from pathlib import Path

from .digitraffic_client import DigitrafficClient
from .normalizer import extract_traffic_version
from ...redis_state import RedisState


def main() -> None:
    client = DigitrafficClient(RedisState())
    data = client.fetch_stations()
    root = Path(__file__).resolve().parents[4]
    out_dir = root / "docs" / "data"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "digitraffic_sample.json"
    out_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    version = extract_traffic_version(data)
    print(f"saved: {out_path}")
    print(f"traffic_version: {version}")


if __name__ == "__main__":
    main()
