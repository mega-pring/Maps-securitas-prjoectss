from __future__ import annotations

from dataclasses import dataclass


@dataclass
class StationMetric:
    lat: float
    lon: float
    speed_kmh: float | None
    volume: float | None


def normalize_station(feature: dict) -> StationMetric | None:
    geometry = feature.get("geometry", {})
    coords = geometry.get("coordinates", [])
    if not coords or len(coords) < 2:
        return None
    lon, lat = coords[0], coords[1]

    props = feature.get("properties", {})
    speed = None
    volume = None
    for sv in props.get("sensorValues", []):
        name = sv.get("name", "").upper()
        value = sv.get("value")
        if value is None:
            continue
        if "KESKINOPEUS" in name or "AVERAGE_SPEED" in name:
            speed = float(value)
        if "VOLUME" in name or "AJONEUVO" in name:
            volume = float(value)

    return StationMetric(lat=float(lat), lon=float(lon), speed_kmh=speed, volume=volume)


def normalize_snapshot(snapshot: dict) -> list[StationMetric]:
    metrics = []
    for feat in snapshot.get("features", []):
        m = normalize_station(feat)
        if m:
            metrics.append(m)
    return metrics


def extract_traffic_version(snapshot: dict) -> str:
    meta = snapshot.get("dataUpdatedTime") or snapshot.get("lastUpdated")
    if meta:
        return str(meta)
    return str(hash(str(snapshot)))[-8:]