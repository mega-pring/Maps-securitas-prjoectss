from __future__ import annotations

from dataclasses import dataclass

from .normalizer import StationMetric


@dataclass
class GridFactor:
    key: str
    factor: float


def cell_factor(lat: float, lon: float, stations: list[StationMetric]) -> float:
    if not stations:
        return 1.0
    nearest = sorted(stations, key=lambda s: (s.lat - lat) ** 2 + (s.lon - lon) ** 2)[:3]
    speeds = [s.speed_kmh for s in nearest if s.speed_kmh]
    if not speeds:
        return 1.0
    avg_speed = sum(speeds) / len(speeds)
    return max(0.3, min(1.3, avg_speed / 80.0))