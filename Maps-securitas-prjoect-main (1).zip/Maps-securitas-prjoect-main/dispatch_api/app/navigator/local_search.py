from __future__ import annotations

import time
from dataclasses import dataclass

from ..config import settings
from .constraints import TimeWindow, late_penalty, priority_penalty
from .leg_cache import LegCost


@dataclass
class TaskNode:
    id: str
    lat: float
    lon: float
    priority: int
    service_time_sec: int
    time_window: TimeWindow | None


def schedule_and_cost(
    get_leg_cost, mode: str, start: TaskNode, plan: list[TaskNode], start_ts: float
) -> dict:
    total = 0.0
    late = 0.0
    eta_total = 0.0
    arrivals: list[float] = []
    departures: list[float] = []
    prefix_totals: list[float] = []
    cur = start
    ts = start_ts
    for idx, t in enumerate(plan):
        leg: LegCost = get_leg_cost(mode, (cur.lat, cur.lon), (t.lat, t.lon))
        eta_total += leg.eta_traffic
        ts += leg.eta_traffic
        lp = late_penalty(ts, t.time_window)
        late += lp
        total += leg.fuel_cost_total + priority_penalty(t.priority, idx) + lp
        arrivals.append(ts)
        ts += t.service_time_sec
        departures.append(ts)
        prefix_totals.append(total)
        cur = t
    return {
        "total": total,
        "late": late,
        "eta_total": eta_total,
        "arrivals": arrivals,
        "departures": departures,
        "prefix_totals": prefix_totals,
    }


def _recompute_from_index(
    get_leg_cost,
    mode: str,
    start: TaskNode,
    plan: list[TaskNode],
    start_ts: float,
    from_index: int,
    prefix_total: float,
    prefix_departure_ts: float,
    prefix_node: TaskNode,
) -> float:
    total = prefix_total
    ts = prefix_departure_ts
    cur = prefix_node
    for idx in range(from_index, len(plan)):
        t = plan[idx]
        leg: LegCost = get_leg_cost(mode, (cur.lat, cur.lon), (t.lat, t.lon))
        ts += leg.eta_traffic
        lp = late_penalty(ts, t.time_window)
        if lp >= settings.hard_window_inf_penalty:
            return settings.hard_window_inf_penalty
        total += leg.fuel_cost_total + priority_penalty(t.priority, idx) + lp
        ts += t.service_time_sec
        cur = t
    return total


def delta_swap(
    get_leg_cost,
    mode: str,
    start: TaskNode,
    plan: list[TaskNode],
    i: int,
    j: int,
    start_ts: float,
    prefix_totals: list[float],
    prefix_departures: list[float],
) -> float:
    if i == j:
        return 0.0
    new_plan = plan[:]
    new_plan[i], new_plan[j] = new_plan[j], new_plan[i]
    from_index = min(i, j)
    if from_index == 0:
        return _recompute_from_index(
            get_leg_cost, mode, start, new_plan, start_ts, 0, 0.0, start_ts, start
        )
    return _recompute_from_index(
        get_leg_cost,
        mode,
        start,
        new_plan,
        start_ts,
        from_index,
        prefix_totals[from_index - 1],
        prefix_departures[from_index - 1],
        new_plan[from_index - 1],
    )


def delta_relocate(
    get_leg_cost,
    mode: str,
    start: TaskNode,
    plan: list[TaskNode],
    i: int,
    j: int,
    start_ts: float,
    prefix_totals: list[float],
    prefix_departures: list[float],
) -> float:
    if i == j:
        return 0.0
    new_plan = plan[:]
    node = new_plan.pop(i)
    new_plan.insert(j, node)
    from_index = min(i, j)
    if from_index == 0:
        return _recompute_from_index(
            get_leg_cost, mode, start, new_plan, start_ts, 0, 0.0, start_ts, start
        )
    return _recompute_from_index(
        get_leg_cost,
        mode,
        start,
        new_plan,
        start_ts,
        from_index,
        prefix_totals[from_index - 1],
        prefix_departures[from_index - 1],
        new_plan[from_index - 1],
    )


def delta_2opt(
    get_leg_cost,
    mode: str,
    start: TaskNode,
    plan: list[TaskNode],
    i: int,
    j: int,
    start_ts: float,
    prefix_totals: list[float],
    prefix_departures: list[float],
) -> float:
    new_plan = plan[:i] + list(reversed(plan[i:j])) + plan[j:]
    from_index = i
    if from_index == 0:
        return _recompute_from_index(
            get_leg_cost, mode, start, new_plan, start_ts, 0, 0.0, start_ts, start
        )
    return _recompute_from_index(
        get_leg_cost,
        mode,
        start,
        new_plan,
        start_ts,
        from_index,
        prefix_totals[from_index - 1],
        prefix_departures[from_index - 1],
        new_plan[from_index - 1],
    )


def local_search(
    get_leg_cost,
    mode: str,
    start: TaskNode,
    plan: list[TaskNode],
    start_ts: float,
    time_budget_ms: int | None = None,
    max_iters: int | None = None,
) -> list[TaskNode]:
    best = plan[:]
    base = schedule_and_cost(get_leg_cost, mode, start, best, start_ts)
    best_cost = base["total"]
    prefix_totals: list[float] = base["prefix_totals"]
    prefix_departures: list[float] = base["departures"]
    no_improve = 0
    t0 = time.time()
    budget_ms = time_budget_ms or settings.local_search_time_budget_ms
    iters = max_iters or settings.local_search_iters

    def rebuild() -> None:
        nonlocal base, prefix_totals, prefix_departures, best_cost
        base = schedule_and_cost(get_leg_cost, mode, start, best, start_ts)
        best_cost = base["total"]
        prefix_totals = base["prefix_totals"]
        prefix_departures = base["departures"]

    for _ in range(iters):
        improved = False
        for i in range(len(best)):
            for j in range(i + 1, len(best)):
                cand_cost = delta_swap(
                    get_leg_cost,
                    mode,
                    start,
                    best,
                    i,
                    j,
                    start_ts,
                    prefix_totals,
                    prefix_departures,
                )
                if cand_cost < best_cost:
                    best[i], best[j] = best[j], best[i]
                    rebuild()
                    improved = True
        for i in range(len(best)):
            for j in range(len(best)):
                if i == j:
                    continue
                cand_cost = delta_relocate(
                    get_leg_cost,
                    mode,
                    start,
                    best,
                    i,
                    j,
                    start_ts,
                    prefix_totals,
                    prefix_departures,
                )
                if cand_cost < best_cost:
                    node = best.pop(i)
                    best.insert(j, node)
                    rebuild()
                    improved = True
        for i in range(1, len(best) - 1):
            for j in range(i + 1, len(best)):
                cand_cost = delta_2opt(
                    get_leg_cost,
                    mode,
                    start,
                    best,
                    i,
                    j,
                    start_ts,
                    prefix_totals,
                    prefix_departures,
                )
                if cand_cost < best_cost:
                    best = best[:i] + list(reversed(best[i:j])) + best[j:]
                    rebuild()
                    improved = True
        if not improved:
            no_improve += 1
        if no_improve > 10:
            break
        if (time.time() - t0) * 1000 > budget_ms:
            break
    return best
