from __future__ import annotations

import time

from ..config import settings
from ..db import insert_event
from ..redis_state import RedisState
from .cost import eta_freeflow, eta_traffic, fuel_cost, route_summary
from .leg_cache import LegCache, LegCost
from .profiles import EMERGENCY_ETA_PROFILE, PATROL_FUEL_PROFILE, TransportProfile
from .router import route as valhalla_route
from .traffic.provider import TrafficProvider, get_traffic_provider


class NavigatorService:
    def __init__(self) -> None:
        self.redis = RedisState()
        self.traffic: TrafficProvider = get_traffic_provider()
        self.leg_cache = LegCache(self.redis)

    def _mode_profile(self, mode: str):
        return EMERGENCY_ETA_PROFILE if mode == "EMERGENCY_ETA" else PATROL_FUEL_PROFILE

    def route(self, mode: str, a: dict, b: dict, alternates: int = 0) -> dict:
        return valhalla_route(mode, a, b, alternates=alternates)

    def get_leg_cost(
        self,
        mode: str,
        a: tuple[float, float],
        b: tuple[float, float],
        traffic_version: str,
        vehicle: TransportProfile,
        approximate: bool = False,
    ) -> LegCost:
        time_bucket = int(time.time() / settings.leg_time_bucket_sec)
        key = self.leg_cache.key(mode, a, b, time_bucket, traffic_version, vehicle.__dict__)
        cached = self.leg_cache.get(key)
        if cached:
            return cached

        if approximate:
            length_km = ((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2) ** 0.5 * 111
            eta_ff = length_km * 60
            eta_tr = eta_ff
            return LegCost(
                eta_freeflow=eta_ff,
                eta_traffic=eta_tr,
                fuel_cost_total=length_km * 1000,
                length_km=length_km,
                breakdown={},
            )

        route = self.route(
            mode,
            {"lat": a[0], "lon": a[1]},
            {"lat": b[0], "lon": b[1]},
            alternates=1,
        )
        summary = route_summary(route)
        traffic_info = self.traffic.annotate_route(_shape_points(route), time.time())
        eta_ff = eta_freeflow(route)
        eta_tr = eta_traffic(eta_ff, traffic_info)
        fuel = fuel_cost(route, traffic_info, vehicle)
        leg = LegCost(
            eta_freeflow=eta_ff,
            eta_traffic=eta_tr,
            fuel_cost_total=fuel.total,
            length_km=summary["length_km"],
            breakdown=fuel.__dict__,
        )
        self.leg_cache.set(key, leg)
        insert_event("navigator_route_built", {"mode": mode, "eta": eta_tr, "fuel": fuel.total})
        return leg


def _decode_polyline(encoded: str, precision: int = 6) -> list[tuple[float, float]]:
    coords: list[tuple[float, float]] = []
    index = 0
    lat = 0
    lon = 0
    factor = 10 ** precision
    while index < len(encoded):
        shift = 0
        result = 0
        while True:
            b = ord(encoded[index]) - 63
            index += 1
            result |= (b & 0x1F) << shift
            shift += 5
            if b < 0x20:
                break
        dlat = ~(result >> 1) if result & 1 else result >> 1
        lat += dlat
        shift = 0
        result = 0
        while True:
            b = ord(encoded[index]) - 63
            index += 1
            result |= (b & 0x1F) << shift
            shift += 5
            if b < 0x20:
                break
        dlon = ~(result >> 1) if result & 1 else result >> 1
        lon += dlon
        coords.append((lat / factor, lon / factor))
    return coords


def _shape_points(route: dict) -> list[tuple[float, float]]:
    trip = route.get("trip", {})
    legs = trip.get("legs", [])
    if not legs:
        return []
    shape = legs[0].get("shape")
    if isinstance(shape, list):
        return [(p[0], p[1]) for p in shape]
    if isinstance(shape, str):
        return _decode_polyline(shape, precision=6)
    return []
