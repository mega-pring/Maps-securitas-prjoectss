from __future__ import annotations

from .constraints import priority_weight
from .cost import eta_traffic, fuel_cost
from .profiles import TransportProfile


VehicleProfile = TransportProfile


def eta_with_traffic(time_sec: float, traffic: dict | None) -> float:
    return eta_traffic(time_sec, traffic)
