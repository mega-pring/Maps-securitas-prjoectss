from __future__ import annotations

import hashlib
import json
import time
from collections import OrderedDict
from dataclasses import dataclass

from ..config import settings
from ..redis_state import RedisState


@dataclass
class LegCost:
    eta_freeflow: float
    eta_traffic: float
    fuel_cost_total: float
    length_km: float
    breakdown: dict


class LRUCache:
    def __init__(self, max_size: int = 1024) -> None:
        self.max_size = max_size
        self.data: OrderedDict[str, LegCost] = OrderedDict()

    def get(self, key: str) -> LegCost | None:
        if key in self.data:
            self.data.move_to_end(key)
            return self.data[key]
        return None

    def set(self, key: str, value: LegCost) -> None:
        self.data[key] = value
        self.data.move_to_end(key)
        if len(self.data) > self.max_size:
            self.data.popitem(last=False)


class LegCache:
    def __init__(self, redis_state: RedisState, max_size: int = 1024) -> None:
        self.redis = redis_state
        self.lru = LRUCache(max_size=max_size)

    def _vehicle_hash(self, vehicle: dict) -> str:
        raw = json.dumps(vehicle, sort_keys=True)
        return hashlib.sha1(raw.encode()).hexdigest()[:8]

    def key(
        self,
        mode: str,
        a: tuple[float, float],
        b: tuple[float, float],
        time_bucket: int,
        traffic_version: str,
        vehicle: dict,
    ) -> str:
        veh = self._vehicle_hash(vehicle)
        return (
            f"leg:{mode}:{a[0]:.5f},{a[1]:.5f}:"
            f"{b[0]:.5f},{b[1]:.5f}:{time_bucket}:{traffic_version}:{veh}"
        )

    def get(self, key: str) -> LegCost | None:
        val = self.lru.get(key)
        if val:
            return val
        raw = self.redis.client.get(key)
        if not raw:
            return None
        data = json.loads(raw)
        val = LegCost(**data)
        self.lru.set(key, val)
        return val

    def set(self, key: str, value: LegCost) -> None:
        self.lru.set(key, value)
        payload = json.dumps(value.__dict__)
        self.redis.client.setex(key, settings.leg_cache_ttl_sec, payload)
