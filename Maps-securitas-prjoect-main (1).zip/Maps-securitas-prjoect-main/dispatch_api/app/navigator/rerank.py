from __future__ import annotations

from typing import Iterable


def select_emergency(candidates: Iterable[dict]) -> dict | None:
    best = None
    for c in candidates:
        if best is None or (c["eta_traffic"], c.get("disruption", 0)) < (
            best["eta_traffic"],
            best.get("disruption", 0),
        ):
            best = c
    return best


def select_patrol_fuel(
    candidates: Iterable[dict],
    best_eta: float,
    fuel_max_detour_pct: float,
    fuel_eta_tradeoff_k: float,
) -> dict | None:
    best = None
    for c in candidates:
        eta = c["eta_traffic"]
        fuel = c["fuel_cost"]
        skip_pen = c.get("skip_penalty", 0.0)
        if eta > best_eta * (1 + fuel_max_detour_pct):
            score = fuel + fuel_eta_tradeoff_k * (eta - best_eta) + skip_pen
        else:
            score = fuel + skip_pen
        c = {**c, "score": score}
        if best is None or c["score"] < best["score"]:
            best = c
    return best
