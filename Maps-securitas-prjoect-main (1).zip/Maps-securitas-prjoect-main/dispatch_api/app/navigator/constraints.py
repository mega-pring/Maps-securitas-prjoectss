from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from ..config import settings


def parse_iso(ts: str | None) -> float | None:
    if not ts:
        return None
    return datetime.fromisoformat(ts.replace("Z", "+00:00")).timestamp()


@dataclass
class TimeWindow:
    open_ts: float
    close_ts: float
    hard: bool = False


def late_penalty(arrival_ts: float, tw: TimeWindow | None) -> float:
    if not tw:
        return 0.0
    if arrival_ts <= tw.close_ts:
        return 0.0
    if tw.hard:
        return settings.hard_window_inf_penalty
    return settings.late_coeff * (arrival_ts - tw.close_ts)


def priority_weight(priority: int) -> float:
    p = max(1, min(5, priority))
    if settings.priority_mode == "exp":
        return 2.71828 ** (settings.priority_exp * (p - 1))
    return 1.0 + settings.priority_linear * (p - 1)


def miss_penalty(priority: int) -> float:
    return settings.miss_coeff * priority_weight(priority)


def priority_penalty(priority: int, position_index: int) -> float:
    return settings.priority_linear * priority_weight(priority) * position_index