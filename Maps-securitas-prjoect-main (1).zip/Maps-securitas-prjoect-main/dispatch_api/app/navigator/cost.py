from __future__ import annotations

from dataclasses import dataclass

from ..config import settings


def route_summary(route_payload: dict) -> dict:
    trip = route_payload.get("trip", {})
    summary = trip.get("summary", {})
    length_km = float(summary.get("length", 0.0))
    time_sec = int(summary.get("time", 0))
    maneuvers = 0
    legs = trip.get("legs", [])
    if legs:
        maneuvers = len(legs[0].get("maneuvers", []))
    return {
        "length_km": length_km,
        "time_sec": time_sec,
        "maneuvers": maneuvers,
        "shape": legs[0].get("shape") if legs else None,
    }


def eta_freeflow(route_payload: dict) -> float:
    return float(route_summary(route_payload)["time_sec"])


def eta_traffic(eta_ff: float, traffic_annotation: dict | None) -> float:
    avg_factor = 1.0
    if traffic_annotation:
        avg_factor = max(0.3, min(1.3, float(traffic_annotation.get("avg_factor", 1.0))))
    return eta_ff / avg_factor


@dataclass
class FuelBreakdown:
    total: float
    distance_m: float
    turns: int
    stop_and_go: float
    urban_proxy: float
    traffic_penalty: float


def fuel_cost(
    route_payload: dict,
    traffic_annotation: dict | None,
    vehicle,
    coeffs=None,
) -> FuelBreakdown:
    summary = route_summary(route_payload)
    length_m = summary["length_km"] * 1000.0
    maneuvers = summary["maneuvers"]
    avg_factor = 1.0
    congested_share = 0.0
    if traffic_annotation:
        avg_factor = max(0.3, min(1.3, float(traffic_annotation.get("avg_factor", 1.0))))
        congested_share = float(traffic_annotation.get("congested_share", 0.0))

    turn_density = maneuvers / max(0.1, summary["length_km"])
    stop_and_go = congested_share * turn_density
    urban_proxy = min(1.0, turn_density / 10.0)
    traffic_penalty = max(0.0, (1.0 / avg_factor - 1.0))

    mass_factor = 1.0 + settings.mass_stopgo_scale * max(
        0.0, (vehicle.mass_kg - settings.mass_ref_kg) / settings.mass_ref_kg
    )
    eco = vehicle.eco_bias

    total = (
        settings.alpha_distance_m * length_m
        + settings.beta_turn_count * maneuvers
        + settings.gamma_stopandgo * stop_and_go * mass_factor * eco
        + settings.delta_urban * urban_proxy * eco
        + settings.epsilon_traffic * length_m * traffic_penalty * mass_factor
    )

    return FuelBreakdown(
        total=float(total),
        distance_m=length_m,
        turns=maneuvers,
        stop_and_go=stop_and_go,
        urban_proxy=urban_proxy,
        traffic_penalty=traffic_penalty,
    )
