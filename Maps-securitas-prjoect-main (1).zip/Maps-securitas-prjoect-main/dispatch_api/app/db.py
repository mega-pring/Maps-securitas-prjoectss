import json
from contextlib import contextmanager

import psycopg2
from psycopg2.pool import SimpleConnectionPool

from .config import settings

_pool: SimpleConnectionPool | None = None


def init_db() -> None:
    global _pool
    if _pool is None:
        _pool = SimpleConnectionPool(1, 10, dsn=settings.postgres_dsn)


@contextmanager
def get_conn():
    if _pool is None:
        init_db()
    assert _pool is not None
    conn = _pool.getconn()
    try:
        yield conn
    finally:
        _pool.putconn(conn)


def execute(query: str, params: tuple | None = None) -> None:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(query, params)
        conn.commit()


def fetch_one(query: str, params: tuple | None = None):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(query, params)
            row = cur.fetchone()
        return row


def fetch_all(query: str, params: tuple | None = None):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(query, params)
            rows = cur.fetchall()
        return rows


def insert_event(event_type: str, payload: dict) -> None:
    execute(
        "INSERT INTO events(type, payload) VALUES (%s, %s)",
        (event_type, json.dumps(payload)),
    )