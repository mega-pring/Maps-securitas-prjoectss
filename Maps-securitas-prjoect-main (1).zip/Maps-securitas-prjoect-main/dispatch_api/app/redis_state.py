import json
from datetime import datetime, timezone

import redis

from .config import settings
from .utils import grid_cell


class RedisState:
    def __init__(self) -> None:
        self.client = redis.Redis.from_url(settings.redis_url, decode_responses=True)

    def set_vehicle_state(
        self,
        vehicle_id: str,
        lat: float,
        lon: float,
        status: str,
        mode: str,
        next_patrol_index: int,
    ) -> None:
        cell = grid_cell(lat, lon, settings.grid_km)
        key = f"veh:{vehicle_id}"
        now = datetime.now(timezone.utc).isoformat()
        self.client.hset(
            key,
            mapping={
                "lat": lat,
                "lon": lon,
                "status": status,
                "mode": mode,
                "next_patrol_index": next_patrol_index,
                "grid_cell": cell,
                "last_ts": now,
            },
        )
        self.client.sadd("vehicles", vehicle_id)
        self._update_grid_membership(vehicle_id, cell)

    def update_location(
        self,
        vehicle_id: str,
        lat: float,
        lon: float,
        speed_mps: float | None,
        heading: float | None,
        timestamp: str,
    ) -> None:
        key = f"veh:{vehicle_id}"
        cell = grid_cell(lat, lon, settings.grid_km)
        prev_cell = self.client.hget(key, "grid_cell")
        self.client.hset(
            key,
            mapping={
                "lat": lat,
                "lon": lon,
                "grid_cell": cell,
                "last_ts": timestamp,
                "speed_mps": speed_mps or 0,
                "heading": heading or 0,
            },
        )
        if prev_cell and prev_cell != cell:
            self.client.srem(f"grid:{prev_cell}", vehicle_id)
        self._update_grid_membership(vehicle_id, cell)

    def update_status(self, vehicle_id: str, status: str) -> None:
        self.client.hset(f"veh:{vehicle_id}", "status", status)

    def update_mode(self, vehicle_id: str, mode: str) -> None:
        self.client.hset(f"veh:{vehicle_id}", "mode", mode)

    def update_next_patrol_index(self, vehicle_id: str, next_index: int) -> None:
        self.client.hset(f"veh:{vehicle_id}", "next_patrol_index", next_index)

    def set_active_route(self, vehicle_id: str, route_id: str) -> None:
        self.client.hset(f"veh:{vehicle_id}", "active_route_id", route_id)

    def get_vehicle(self, vehicle_id: str) -> dict:
        data = self.client.hgetall(f"veh:{vehicle_id}")
        if not data:
            return {}
        decoded: dict[str, str] = {}
        for k, v in data.items():
            key = k.decode() if isinstance(k, (bytes, bytearray)) else str(k)
            val = v.decode() if isinstance(v, (bytes, bytearray)) else str(v)
            decoded[key] = val
        return decoded

    def get_all_vehicle_ids(self) -> list[str]:
        ids = self.client.smembers("vehicles")
        return [i.decode() if isinstance(i, (bytes, bytearray)) else str(i) for i in ids]

    def get_vehicles_in_cells(self, cells: list[str]) -> list[str]:
        ids: set[str] = set()
        for cell in cells:
            ids.update(self.client.smembers(f"grid:{cell}"))
        return list(ids)

    def cache_route(self, key: str, payload: dict, ttl_sec: int) -> None:
        self.client.setex(f"route_cache:{key}", ttl_sec, json.dumps(payload))

    def get_cached_route(self, key: str) -> dict | None:
        raw = self.client.get(f"route_cache:{key}")
        if not raw:
            return None
        return json.loads(raw)

    def set_route_payload(self, route_id: str, payload: dict, ttl_sec: int = 3600) -> None:
        self.client.setex(f"route:{route_id}", ttl_sec, json.dumps(payload))

    def get_route_payload(self, route_id: str) -> dict | None:
        raw = self.client.get(f"route:{route_id}")
        if not raw:
            return None
        return json.loads(raw)

    def _update_grid_membership(self, vehicle_id: str, cell: str) -> None:
        self.client.sadd(f"grid:{cell}", vehicle_id)
