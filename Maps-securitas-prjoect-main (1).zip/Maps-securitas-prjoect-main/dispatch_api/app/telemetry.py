from fastapi import APIRouter, HTTPException

from .algorithms import fuel_score, route_summary
from .db import fetch_all, fetch_one
from .redis_state import RedisState

router = APIRouter(prefix="/telemetry")
redis_state = RedisState()


@router.get("/vehicle/{vehicle_id}")
def telemetry_vehicle(vehicle_id: str):
    state = redis_state.get_vehicle(vehicle_id)
    if not state:
        raise HTTPException(status_code=404, detail="vehicle_not_found")
    state["vehicle_id"] = vehicle_id
    return state


@router.get("/route/{vehicle_id}")
def telemetry_route(vehicle_id: str):
    state = redis_state.get_vehicle(vehicle_id)
    if not state:
        raise HTTPException(status_code=404, detail="vehicle_not_found")
    route_id = state.get("active_route_id")
    if not route_id:
        raise HTTPException(status_code=404, detail="no_active_route")
    payload = redis_state.get_route_payload(route_id)
    if not payload:
        raise HTTPException(status_code=404, detail="route_not_cached")
    summary = route_summary(payload)
    maneuvers = []
    trip = payload.get("trip", {})
    legs = trip.get("legs", [])
    if legs:
        for m in legs[0].get("maneuvers", []):
            maneuvers.append(
                {
                    "instruction": m.get("instruction"),
                    "length_km": m.get("length"),
                    "time_sec": m.get("time"),
                    "type": m.get("type"),
                }
            )
    return {
        "route_id": route_id,
        "mode": payload.get("_mode"),
        "shape": summary.get("shape"),
        "summary": {"time_sec": summary["time_sec"], "length_km": summary["length_km"]},
        "fuel_score": fuel_score(payload),
        "maneuvers": maneuvers,
    }


@router.get("/patrol/{vehicle_id}")
def telemetry_patrol(vehicle_id: str):
    route_row = fetch_one(
        "SELECT id FROM patrol_routes WHERE vehicle_id=%s ORDER BY created_at DESC LIMIT 1",
        (vehicle_id,),
    )
    if not route_row:
        return {"points": []}
    route_id = route_row[0]
    points = fetch_all(
        "SELECT seq, lat, lon FROM patrol_points WHERE route_id=%s ORDER BY seq ASC",
        (route_id,),
    )
    return {"points": [{"seq": p[0], "lat": p[1], "lon": p[2]} for p in points]}
