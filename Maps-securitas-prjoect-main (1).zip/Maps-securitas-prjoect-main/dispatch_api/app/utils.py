import math


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371.0
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def grid_cell(lat: float, lon: float, grid_km: float) -> str:
    lat_deg = grid_km / 111.0
    lon_deg = grid_km / (111.0 * max(0.2, math.cos(math.radians(lat))))
    gx = int(math.floor(lon / lon_deg))
    gy = int(math.floor(lat / lat_deg))
    return f"{gx}:{gy}"


def neighbor_cells(cell: str) -> list[str]:
    gx, gy = cell.split(":")
    cx = int(gx)
    cy = int(gy)
    return [f"{x}:{y}" for x in range(cx - 1, cx + 2) for y in range(cy - 1, cy + 2)]