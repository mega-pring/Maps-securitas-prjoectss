import json
import math
import time
from abc import ABC, abstractmethod
from urllib.parse import urlparse

import httpx

from ..config import settings
from ..redis_state import RedisState


class TrafficProvider(ABC):
    @abstractmethod
    def get_cell_factor(self, lat: float, lon: float, ts: float) -> float:
        raise NotImplementedError

    @abstractmethod
    def annotate_route(self, shape_points: list[tuple[float, float]], ts: float) -> dict:
        raise NotImplementedError


class SyntheticTrafficProvider(TrafficProvider):
    def __init__(self, seed: int = 42, grid_km: float = 1.0) -> None:
        self.seed = seed
        self.grid_km = grid_km

    def _wave(self, ts: float) -> float:
        day = 24 * 3600
        phase = (ts % day) / day
        morning = math.sin((phase - 0.25) * 2 * math.pi)
        evening = math.sin((phase - 0.65) * 2 * math.pi)
        return (morning + evening) * 0.15

    def get_cell_factor(self, lat: float, lon: float, ts: float) -> float:
        base = 0.95
        jitter = 0.05 * math.sin((lat + lon + ts / 3600.0) * 10)
        factor = base + self._wave(ts) + jitter
        return max(0.3, min(1.3, factor))

    def annotate_route(self, shape_points: list[tuple[float, float]], ts: float) -> dict:
        if not shape_points:
            return {"avg_factor": 1.0, "congested_share": 0.0}
        sample = shape_points[:: max(1, len(shape_points) // 50) or 1]
        factors = [self.get_cell_factor(p[0], p[1], ts) for p in sample]
        avg = sum(factors) / max(1, len(factors))
        congested = sum(1 for f in factors if f < 0.8) / max(1, len(factors))
        return {"avg_factor": max(0.3, min(1.3, avg)), "congested_share": congested}


class DigitrafficTrafficProvider(TrafficProvider):
    def __init__(self, redis_state: RedisState, grid_km: float = 1.0) -> None:
        self.redis = redis_state
        self.grid_km = grid_km
        self.base_url = settings.traffic_base_url.rstrip("/")

    def _validate_base_url(self) -> None:
        parsed = urlparse(self.base_url)
        if parsed.scheme != "https":
            raise ValueError("traffic_base_url must be https")
        if parsed.netloc not in {"tie.digitraffic.fi"}:
            raise ValueError("traffic_base_url not allowed")

    def _rate_limit(self) -> None:
        key = "traffic:ratelimit"
        now = time.monotonic()
        last = self.redis.client.get(key)
        min_interval = 1.0 / max(0.1, settings.traffic_rps)
        if last and now - float(last) < min_interval:
            raise RuntimeError("traffic_rate_limited")
        self.redis.client.setex(key, 2, str(now))

    def _fetch_snapshot(self) -> dict:
        cache_key = "traffic:snapshot"
        cached = self.redis.client.get(cache_key)
        if cached:
            return json.loads(cached)
        self._validate_base_url()
        self._rate_limit()
        url = f"{self.base_url}/api/tms/v1/stations/data"
        headers = {"User-Agent": settings.nominatim_user_agent}
        with httpx.Client(timeout=5) as client:
            resp = client.get(url, headers=headers)
            resp.raise_for_status()
        data = resp.json()
        self.redis.client.setex(cache_key, settings.traffic_cache_ttl_sec, json.dumps(data))
        return data

    def _station_speed_kmh(self, station: dict) -> float | None:
        for sv in station.get("sensorValues", []):
            name = sv.get("name", "")
            if "KESKINOPEUS" in name:
                value = sv.get("value")
                if value is not None:
                    return float(value)
        return None

    def get_cell_factor(self, lat: float, lon: float, ts: float) -> float:
        try:
            data = self._fetch_snapshot()
        except Exception:
            return 1.0
        factors = []
        for station in data.get("features", []):
            props = station.get("properties", {})
            geometry = station.get("geometry", {})
            coords = geometry.get("coordinates", [])
            if not coords or len(coords) < 2:
                continue
            s_lon, s_lat = coords[0], coords[1]
            dist = (lat - s_lat) ** 2 + (lon - s_lon) ** 2
            if dist > 0.002:
                continue
            speed = self._station_speed_kmh(props)
            if speed:
                factor = max(0.3, min(1.3, speed / 80.0))
                factors.append(factor)
        if not factors:
            return 1.0
        return sum(factors) / len(factors)

    def annotate_route(self, shape_points: list[tuple[float, float]], ts: float) -> dict:
        if not shape_points:
            return {"avg_factor": 1.0, "congested_share": 0.0}
        sample = shape_points[:: max(1, len(shape_points)//30) or 1]
        factors = [self.get_cell_factor(p[0], p[1], ts) for p in sample]
        avg = sum(factors) / max(1, len(factors))
        congested = sum(1 for f in factors if f < 0.8) / max(1, len(factors))
        return {"avg_factor": max(0.3, min(1.3, avg)), "congested_share": congested}


def get_traffic_provider() -> TrafficProvider:
    if settings.traffic_provider.lower() == "synthetic":
        return SyntheticTrafficProvider(seed=42, grid_km=settings.grid_km)
    return DigitrafficTrafficProvider(redis_state=RedisState(), grid_km=settings.grid_km)
