from typing import Any

from .config import settings


def route_summary(route: dict) -> dict:
    trip = route.get("trip", {})
    summary = trip.get("summary", {})
    length_km = summary.get("length", 0.0)
    time_sec = summary.get("time", 0)
    maneuvers = 0
    legs = trip.get("legs", [])
    if legs:
        maneuvers = len(legs[0].get("maneuvers", []))
    return {
        "length_km": float(length_km),
        "time_sec": int(time_sec),
        "maneuvers": int(maneuvers),
        "shape": trip.get("legs", [{}])[0].get("shape"),
    }


def urban_proxy(length_km: float, time_sec: int, maneuvers: int) -> float:
    if time_sec <= 0 or length_km <= 0:
        return 0.0
    speed_kmh = (length_km / (time_sec / 3600.0)) if time_sec > 0 else 0
    slow_penalty = max(0.0, 15.0 - speed_kmh)
    maneuver_penalty = maneuvers * 0.05
    return slow_penalty + maneuver_penalty


def fuel_score(route: dict) -> float:
    summary = route_summary(route)
    length_m = summary["length_km"] * 1000.0
    maneuvers = summary["maneuvers"]
    urban = urban_proxy(summary["length_km"], summary["time_sec"], maneuvers)
    road_class_proxy = 0.0
    return (
        settings.alpha_distance_m * length_m
        + settings.beta_turn_count * maneuvers
        + settings.gamma_urban_proxy * urban
        + settings.delta_road_class_proxy * road_class_proxy
    )


def skip_penalty(next_index: int, candidate_index: int) -> float:
    skipped = max(0, candidate_index - next_index)
    return skipped * settings.skip_points_penalty


def compute_disruption(extra_distance_km: float, skip_pen: float) -> float:
    return extra_distance_km + skip_pen


def rejoin_window_indices(next_index: int, max_index: int) -> list[int]:
    end = min(max_index, next_index + settings.rejoin_window_max)
    start = min(max_index, next_index + settings.rejoin_window_min)
    if start > next_index:
        return list(range(start, end + 1))
    return list(range(next_index, end + 1))


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default
