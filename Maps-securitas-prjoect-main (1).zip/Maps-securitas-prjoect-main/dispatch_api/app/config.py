from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    postgres_dsn: str = "postgresql://dispatch:dispatch@postgres:5432/dispatch"
    redis_url: str = "redis://redis:6379/0"
    valhalla_url: str = "http://valhalla:8002"
    log_level: str = "INFO"

    grid_km: float = 1.0
    candidates_n: int = 20
    lambda_disruption: float = 0.4

    alpha_distance_m: float = 1.0
    beta_turn_count: float = 20.0
    gamma_urban_proxy: float = 0.2
    delta_road_class_proxy: float = 0.0

    rejoin_window_min: int = 10
    rejoin_window_max: int = 20
    skip_points_penalty: float = 0.1

    route_cache_ttl_sec: int = 60
    route_cache_bucket_sec: int = 60
    request_timeout_sec: int = 4
    max_gps_age_sec: int = 600
    nominatim_base_url: str = "https://nominatim.openstreetmap.org"
    nominatim_user_agent: str = "patrol-routing-mvp-sim"
    geocode_rps: float = 1.0
    geocode_cache_ttl_sec: int = 86400
    ui_origin: str = "http://localhost:3000"
    traffic_base_url: str = "https://tie.digitraffic.fi"
    traffic_rps: float = 0.5
    traffic_cache_ttl_sec: int = 120
    traffic_provider: str = "digitraffic"
    digitraffic_user: str = "patrol-routing-mvp"

    gamma_stopandgo: float = 0.3
    delta_urban: float = 0.2
    epsilon_traffic: float = 0.15
    mass_ref_kg: float = 1600.0
    mass_stopgo_scale: float = 0.15
    fuel_max_detour_pct: float = 0.35
    fuel_eta_tradeoff_k: float = 0.2

    late_coeff: float = 1.0
    miss_coeff: float = 500.0
    priority_linear: float = 1.0
    priority_exp: float = 0.4
    priority_mode: str = "linear"
    hard_window_inf_penalty: float = 1e12
    patrol_time_budget_ms: int = 800
    patrol_local_search_iters: int = 500
    leg_cache_ttl_sec: int = 120
    leg_time_bucket_sec: int = 60
    local_search_time_budget_ms: int = 1200
    local_search_iters: int = 800

    class Config:
        env_prefix = ""
        case_sensitive = False


settings = Settings()
