import json
import time
from typing import Any

import httpx
from urllib.parse import urlparse
from fastapi import APIRouter, HTTPException, Query

from .config import settings
from .redis_state import RedisState

router = APIRouter(prefix="/geocode")
redis_state = RedisState()

_last_request_ts = 0.0


def _rate_limit() -> None:
    global _last_request_ts
    now = time.monotonic()
    min_interval = 1.0 / max(0.1, settings.geocode_rps)
    if now - _last_request_ts < min_interval:
        raise HTTPException(status_code=429, detail="rate_limited")
    _last_request_ts = now


def _cache_get(key: str) -> dict | None:
    raw = redis_state.client.get(key)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return None


def _cache_set(key: str, value: dict) -> None:
    redis_state.client.setex(key, settings.geocode_cache_ttl_sec, json.dumps(value))

def _validate_base_url() -> None:
    parsed = urlparse(settings.nominatim_base_url)
    if parsed.scheme != "https":
        raise HTTPException(status_code=400, detail="nominatim_base_url_must_be_https")
    if parsed.netloc not in {"nominatim.openstreetmap.org"}:
        raise HTTPException(status_code=400, detail="nominatim_base_url_not_allowed")


@router.get("/search")
@router.post("/search")
def geocode_search(q: str = Query(..., min_length=3, max_length=200)) -> Any:
    cache_key = f"geocode:search:{q.lower()}"
    cached = _cache_get(cache_key)
    if cached:
        return cached

    _rate_limit()
    _validate_base_url()
    url = f"{settings.nominatim_base_url.rstrip('/')}/search"
    params = {"q": q, "format": "json", "limit": 5}
    headers = {"User-Agent": settings.nominatim_user_agent}
    with httpx.Client(timeout=5) as client:
        resp = client.get(url, params=params, headers=headers)
        resp.raise_for_status()
    data = resp.json()
    result = {
        "query": q,
        "results": [
            {
                "display_name": r.get("display_name"),
                "lat": float(r.get("lat")),
                "lon": float(r.get("lon")),
            }
            for r in data
        ],
    }
    _cache_set(cache_key, result)
    return result


@router.get("/reverse")
@router.post("/reverse")
def geocode_reverse(lat: float = Query(...), lon: float = Query(...)) -> Any:
    if not (-90 <= lat <= 90 and -180 <= lon <= 180):
        raise HTTPException(status_code=400, detail="invalid_coordinates")
    cache_key = f"geocode:reverse:{lat:.5f},{lon:.5f}"
    cached = _cache_get(cache_key)
    if cached:
        return cached

    _rate_limit()
    _validate_base_url()
    url = f"{settings.nominatim_base_url.rstrip('/')}/reverse"
    params = {"lat": lat, "lon": lon, "format": "json"}
    headers = {"User-Agent": settings.nominatim_user_agent}
    with httpx.Client(timeout=5) as client:
        resp = client.get(url, params=params, headers=headers)
        resp.raise_for_status()
    data = resp.json()
    result = {
        "lat": lat,
        "lon": lon,
        "display_name": data.get("display_name"),
    }
    _cache_set(cache_key, result)
    return result
