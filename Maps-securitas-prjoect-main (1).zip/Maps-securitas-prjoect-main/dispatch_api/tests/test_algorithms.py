from app.algorithms import fuel_score, route_summary


def test_fuel_score_basic():
    route = {
        "trip": {
            "summary": {"length": 2.0, "time": 600},
            "legs": [{"maneuvers": [1, 2, 3], "shape": "abcd"}],
        }
    }
    score = fuel_score(route)
    assert score > 0
    summary = route_summary(route)
    assert summary["length_km"] == 2.0
    assert summary["time_sec"] == 600
    assert summary["maneuvers"] == 3
