from app.navigator.leg_cache import LegCache
from app.redis_state import RedisState


def test_leg_cache_key_includes_version_and_bucket():
    cache = LegCache(RedisState())
    key = cache.key("PATROL_FUEL", (60.0, 24.0), (60.1, 24.1), 123, "v1", {"mass_kg": 1600})
    assert "PATROL_FUEL" in key
    assert ":123:" in key
    assert ":v1:" in key
