from app.navigator.leg_cache import LegCost
from app.navigator.local_search import TaskNode, local_search


def fake_leg_cost(mode, a, b, approximate=False):
    d = abs(a[0] - b[0]) + abs(a[1] - b[1])
    return LegCost(eta_freeflow=d, eta_traffic=d, fuel_cost_total=d, length_km=d, breakdown={})


def test_local_search_reorders_basic():
    start = TaskNode(id="s", lat=0, lon=0, priority=1, service_time_sec=0, time_window=None)
    plan = [
        TaskNode(id="a", lat=10, lon=0, priority=1, service_time_sec=0, time_window=None),
        TaskNode(id="b", lat=1, lon=0, priority=1, service_time_sec=0, time_window=None),
        TaskNode(id="c", lat=2, lon=0, priority=1, service_time_sec=0, time_window=None),
    ]
    best = local_search(fake_leg_cost, "PATROL_FUEL", start, plan, 0.0)
    assert best[0].id in {"b", "c"}
