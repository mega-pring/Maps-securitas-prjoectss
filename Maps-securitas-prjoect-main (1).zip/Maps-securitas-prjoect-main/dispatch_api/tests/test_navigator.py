from app.navigator.constraints import priority_weight
from app.navigator.cost import eta_traffic, fuel_cost
from app.navigator.profiles import TransportProfile


def test_eta_traffic_bounds():
    eta = eta_traffic(100, {"avg_factor": 0.1})
    assert eta >= 100


def test_fuel_cost_components():
    route = {
        "trip": {
            "summary": {"length": 2.0, "time": 600},
            "legs": [{"maneuvers": [1, 2, 3], "shape": ""}],
        }
    }
    cost = fuel_cost(route, {"avg_factor": 0.8, "congested_share": 0.5}, TransportProfile())
    assert cost.total > 0


def test_priority_weight_linear():
    w1 = priority_weight(1)
    w5 = priority_weight(5)
    assert w5 > w1
