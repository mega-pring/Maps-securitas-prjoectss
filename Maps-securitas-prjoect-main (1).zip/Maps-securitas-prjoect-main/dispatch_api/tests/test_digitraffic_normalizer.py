import json
from pathlib import Path

from app.navigator.traffic.normalizer import extract_traffic_version, normalize_snapshot


def test_digitraffic_normalizer_sample():
    root = Path(__file__).resolve().parents[2]
    sample = root / "docs" / "data" / "digitraffic_sample.json"
    data = json.loads(sample.read_text(encoding="utf-8"))
    stations = normalize_snapshot(data)
    assert len(stations) >= 1
    version = extract_traffic_version(data)
    assert version
