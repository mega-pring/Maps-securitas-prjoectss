from app.navigator.constraints import TimeWindow, late_penalty, parse_iso


def test_late_penalty_soft():
    tw = TimeWindow(open_ts=0, close_ts=10, hard=False)
    p = late_penalty(20, tw)
    assert p > 0


def test_late_penalty_hard():
    tw = TimeWindow(open_ts=0, close_ts=10, hard=True)
    p = late_penalty(20, tw)
    assert p >= 1e12


def test_parse_iso():
    ts = parse_iso("2026-01-28T08:00:00Z")
    assert ts is not None
