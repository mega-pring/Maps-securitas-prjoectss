from app.utils import grid_cell, haversine_km


def test_haversine_km_zero():
    assert haversine_km(60.0, 24.0, 60.0, 24.0) == 0.0


def test_grid_cell_stable():
    cell1 = grid_cell(60.1699, 24.9384, 1.0)
    cell2 = grid_cell(60.1699, 24.9384, 1.0)
    assert cell1 == cell2
