from app.navigator.rerank import select_emergency, select_patrol_fuel


def test_select_emergency_min_eta():
    candidates = [
        {"vehicle_id": "v1", "eta_traffic": 50, "disruption": 5},
        {"vehicle_id": "v2", "eta_traffic": 40, "disruption": 10},
    ]
    best = select_emergency(candidates)
    assert best["vehicle_id"] == "v2"


def test_select_patrol_fuel_detour_penalty():
    candidates = [
        {"id": "a", "eta_traffic": 100, "fuel_cost": 12, "skip_penalty": 0},
        {"id": "b", "eta_traffic": 150, "fuel_cost": 8, "skip_penalty": 0},
    ]
    best = select_patrol_fuel(
        candidates, best_eta=100, fuel_max_detour_pct=0.2, fuel_eta_tradeoff_k=0.5
    )
    assert best["id"] == "a"
