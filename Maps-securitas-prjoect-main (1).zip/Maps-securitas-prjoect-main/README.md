# Patrol Routing + Emergency Dispatch (Valhalla MVP)

MVP for patrol routing and emergency dispatch using Valhalla with a Helsinki test region.

## Repo structure

```
.
+- dispatch_api/          # FastAPI service
+- simulator/             # Load simulator
+- db/                    # schema.sql
+- scripts/               # tile build scripts
+- docs/                  # architecture, API, tuning, assumptions
+- docker-compose.yml
+- Makefile
```

## Quick start (Linux/macOS)

```bash
# 1) copy env
cp .env.example .env

# 2) build tiles (downloads Helsinki PBF + builds tiles)
make tiles

# 3) start stack
make up

# 4) open UI
# http://localhost:3000
# Use UI to add patrol points, start patrol, trigger emergency.
# Single vehicle: veh-001
```

## Quick start (Windows PowerShell)

```powershell
Copy-Item .env.example .env
.\scripts\tiles.ps1

docker compose up -d --build

# UI
# http://localhost:3000
```

## API

See `docs/API.md`.

## Navigator extensions

- POST `/navigator/route`
- POST `/navigator/patrol/optimize`
- Digitraffic sample capture: `python -m dispatch_api.app.navigator.traffic.schema_probe`

## Notes

- Valhalla tiles are built into `data/valhalla`.
- Redis holds live state and short-lived route cache.
- Postgres holds history, calls, assignments, and metrics.
