# Tuning Guide

## Key knobs
- `ALPHA_DISTANCE_M`, `BETA_TURN_COUNT`, `GAMMA_URBAN_PROXY`, `DELTA_ROAD_CLASS_PROXY`
- `LAMBDA_DISRUPTION`
- `REJOIN_WINDOW_MIN`, `REJOIN_WINDOW_MAX`
- `SKIP_POINTS_PENALTY`
- `GRID_KM`
- `CANDIDATES_N`

## Approach
1) Run simulator with baseline values.
2) Track avg ETA, P95 ETA, avg extra km, fuel_score_sum, avg disruption.
3) Increase `LAMBDA_DISRUPTION` if patrol integrity matters more than response time.
4) Increase `ALPHA_DISTANCE_M` to penalize long detours.
5) Increase `BETA_TURN_COUNT` or `GAMMA_URBAN_PROXY` to penalize urban stop-and-go.
6) Keep `CANDIDATES_N` within 10-25 to balance accuracy/cost.

## Tips
- If ETA is too high: increase `CANDIDATES_N` or shrink `GRID_KM`.
- If patrol disruption is too high: increase `LAMBDA_DISRUPTION` or rejoin window size.
- If FuelScore is too high: adjust alpha/beta/gamma or switch to shortest-path weighting in PATROL_FUEL.