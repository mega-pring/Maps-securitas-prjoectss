# Architecture

## Overview

Components:
- dispatch-api (FastAPI) with Valhalla client, Redis state, Postgres persistence.
- valhalla routing engine with tiles built from Helsinki OSM PBF.
- postgres (postgis) for entities, events, metrics.
- redis for live state + route cache.

## Flows

### Patrol
1) Vehicle registers and uploads patrol route points.
2) Vehicle sends location + status updates.
3) API keeps Redis live state (position/status/next_patrol_index/grid_cell).

### Call -> Assign
1) Call created with location and priority.
2) Grid prefilter: fetch candidates from same + neighbor cells.
3) Filter by latest GPS and status, pick top-N by haversine.
4) For top-N, query Valhalla `/route` in EMERGENCY_ETA.
5) Score = ETA_to_call + lambda * PatrolDisruption.
6) Assign best candidate, store assignment, cache route, update Redis.

### Rejoin
1) After call complete, compute rejoin window Pj..Pj+m.
2) For each candidate point, compute PATROL_FUEL cost.
3) Add skip penalty and pick minimum.
4) Return route, update `next_patrol_index`.

## Cache
- Redis short cache for Valhalla routes (30-120s) keyed by mode + from/to + time bucket.

## Indexes
- Postgres: indices on vehicles(id), assignments(call_id, vehicle_id), calls(status), events(created_at), routes_cache(key).
- Redis: grid cell sets for candidate prefilter.