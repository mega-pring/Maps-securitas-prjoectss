# Local Search

## Operators
- swap(i,j): swap two tasks
- relocate(i->j): move one task to new position
- 2-opt(i,j): reverse subsequence

## Delta evaluation
- Recompute only from the earliest changed index.
- Prefix totals and departures are reused from the current best plan.
- Hard window violations return INF penalty.

## Stopping
- time_budget_ms
- max_iters
- early stop after 10 non-improving rounds

## Trade-offs
- Uses cached leg costs to avoid repeated Valhalla calls.
- Greedy insertion + local search provides stable MVP quality without global optimality.
