# API

Base URL: `http://localhost:8000`

## POST /health

```json
{"status":"ok"}
```

## POST /vehicles/register

Request:
```json
{"vehicle_id":"veh-001","mode":"PATROL_FUEL"}
```

Response:
```json
{"vehicle_id":"veh-001"}
```

## POST /vehicles/{id}/location

Request:
```json
{"lat":60.17,"lon":24.94,"speed_mps":8.0,"heading":180,"timestamp":"2026-01-25T03:00:00Z"}
```

Response:
```json
{"ok":true}
```

## POST /vehicles/{id}/status

Request:
```json
{"status":"PATROLLING"}
```

## POST /vehicles/{id}/patrol

Request:
```json
{"points":[{"lat":60.17,"lon":24.94},{"lat":60.18,"lon":24.95}]}
```

## POST /calls/create

Request:
```json
{"call_id":"call-001","lat":60.18,"lon":24.95,"priority":2}
```

Response:
```json
{"call_id":"call-001"}
```

## POST /calls/{id}/assign

Response:
```json
{"vehicle_id":"veh-001","eta_seconds":320,"route_id":"route-123"}
```

## POST /calls/{id}/complete

Request:
```json
{"vehicle_id":"veh-001"}
```

Response:
```json
{"route_id":"route-456","next_patrol_index":12}
```

## GET /vehicles/{id}/route

Response:
```json
{"route_id":"route-123","mode":"EMERGENCY_ETA","shape":"encoded_polyline","summary":{"time":320,"length_km":3.4}}
```

## GET /metrics/summary

Response:
```json
{"avg_eta":310,"p95_eta":540,"avg_extra_km":1.2,"fuel_score_sum":12345,"avg_disruption":0.8}
```