# Model validity (MVP)

## FuelCost proxy
The MVP uses a proxy fuel model that combines distance, turns, stop-and-go and congestion. It is useful for ranking and explaining routing trade-offs in a patrol setting, but it does not claim to match real fuel consumption in liters.

What it captures:
- distance effect (longer routes cost more),
- frequent turns and maneuvers (stop-and-go),
- urban driving proxy (turn density),
- traffic impact (congestion factor).

What it does NOT capture:
- slope/grade, road surface, weather,
- vehicle-specific engine/transmission characteristics,
- driver behavior, idle time accuracy,
- exact fuel at different speeds.

Calibration:
- adjust ALPHA/BETA/GAMMA/DELTA/EPSILON using real vehicle telemetry later,
- tune with A/B tests: compare ETA, fuel proxy, on-time arrival for patrol tasks.

Traffic:
- Digitraffic provides free data but resolution is limited; when unavailable, synthetic traffic is used.
- ETA_traffic is computed as ETA_freeflow / avg_factor with bounds [0.3..1.3].

Limitations:
- traffic factors are coarse grid-based, not per-edge,
- the optimizer is heuristic (greedy + local search) and not globally optimal.