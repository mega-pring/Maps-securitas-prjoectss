# Patrol Optimizer (Single-Vehicle VRPTW)

## Problem
We solve a single-vehicle patrol planning problem with optional time windows and priorities.
This is a VRPTW variant (NP-hard). The MVP uses heuristics.

## Objective
TotalCost(P) =
  sum FuelCost(legs)
+ sum LatePenalty
+ sum MissPenalty
+ sum PriorityPenalty

LatePenalty:
- hard_window: infeasible (huge penalty)
- soft_window: LATE_COEFF * lateness

MissPenalty:
- MISS_COEFF * priority_weight(priority)

PriorityPenalty:
- higher priority tasks earlier when no strict windows.

## Algorithm
1) Greedy insertion based on approximate cost (haversine + priority).
2) Local search (2-opt) to reduce total cost within time budget.
3) Build exact legs using Valhalla; compute ETA_traffic and FuelCost.

## Performance
- Leg costs are approximated first; Valhalla used only for final plan.
- Works in real-time for 1 vehicle and tens of tasks.

## Limitations
- No global optimality guarantee.
- Traffic overlay is coarse (grid / station-based).
- Hard windows may still fail if truly infeasible.