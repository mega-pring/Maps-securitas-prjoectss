# Navigator Architecture

## Components
- NavigatorService: orchestration for Valhalla routing + traffic annotation + leg-cost cache.
- leg_cache: Redis + in-process LRU keyed by mode, rounded coords, time bucket, traffic_version, vehicle hash.
- traffic providers: Digitraffic (primary) + Synthetic (fallback).
- patrol_optimizer: greedy insertion + local search (swap/relocate/2-opt) with time-window penalties.

## Data flow
1) API /navigator/route -> NavigatorService.route -> Valhalla -> traffic annotate -> cost (ETA/Fuel).
2) API /navigator/patrol/optimize -> build plan -> local search -> per-leg routes + schedule.
3) Dispatching uses NavigatorService leg costs for ETA_traffic and fuel reranking.

## Cache keys
- leg:{mode}:{from}:{to}:{time_bucket}:{traffic_version}:{vehicle_hash}
- route cache remains in Redis for Valhalla payloads.

## Traffic
- Digitraffic snapshot cached in Redis (TTL 60-120s).
- Each route gets avg_factor + congested_share + traffic_version.
