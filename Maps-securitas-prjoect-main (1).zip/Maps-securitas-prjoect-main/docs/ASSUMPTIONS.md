# Assumptions

Each assumption includes a criticality level: LOW, MED, HIGH.

- Helsinki PBF source is BBBike Helsinki extract; if unavailable, use any equivalent Helsinki bbox PBF. (MED)
- Valhalla image is `ghcr.io/valhalla/valhalla:latest` with compatible tile build tools. (MED)
- FuelScore proxy uses Valhalla summary + maneuver count; `road_class_proxy` may be 0 if not available. (LOW)
- Grid is 1km square in Web Mercator approximation; neighbor search uses 3x3 grid. (LOW)
- Simulator uses random patrol points inside Helsinki bbox; not map-matched. (LOW)
- ETA uses Valhalla `/route` cost `auto` with `shortest` toggle for PATROL_FUEL. (MED)
- Postgres init uses schema.sql at container start (no migrations). (LOW)
- Redis is authoritative for live state; Postgres is source of record for events. (MED)
- 100 vehicles, 2-3 calls/day/vehicle modeled as ~200 calls per run in simulator. (LOW)
- Digitraffic sample in docs/data is a placeholder unless refreshed via schema_probe. (LOW)
