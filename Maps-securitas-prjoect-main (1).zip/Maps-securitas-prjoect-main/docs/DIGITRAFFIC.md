# Digitraffic

## Endpoint
- https://tie.digitraffic.fi/api/tms/v1/stations/data

## Access rules
- HTTPS only
- Whitelist domain
- Rate limit via Redis (TRAFFIC_RPS)
- Cache snapshot in Redis (TRAFFIC_CACHE_TTL_SEC)

## Sample capture
- Run: python -m dispatch_api.app.navigator.traffic.schema_probe
- Output: docs/data/digitraffic_sample.json

## traffic_version
- Parsed from dataUpdatedTime or lastUpdated
- Used in leg-cache key to prevent stale traffic reuse

## Limitations
- Uses station-level speeds to build grid factors (nearest 1-3 stations)
- No edge-level mapping in MVP
