import math
import random
from dataclasses import dataclass
from datetime import datetime, timezone


@dataclass
class TrafficIncident:
    cell: str
    end_time_sim: float
    factor: float


def grid_cell(lat: float, lon: float, grid_km: float) -> str:
    lat_deg = grid_km / 111.0
    lon_deg = grid_km / (111.0 * max(0.2, math.cos(math.radians(lat))))
    gx = int(math.floor(lon / lon_deg))
    gy = int(math.floor(lat / lat_deg))
    return f"{gx}:{gy}"


def traffic_factor(
    cell: str,
    sim_time_sec: float,
    base: float,
    daily_amp: float,
    noise: float,
    incidents: dict[str, TrafficIncident],
) -> float:
    day_sec = 24 * 3600
    phase = (sim_time_sec % day_sec) / day_sec
    morning_peak = math.sin((phase - 0.25) * 2 * math.pi)
    evening_peak = math.sin((phase - 0.65) * 2 * math.pi)
    wave = (morning_peak + evening_peak) * daily_amp
    jitter = random.uniform(-noise, noise)
    factor = base + wave + jitter
    incident = incidents.get(cell)
    if incident and sim_time_sec <= incident.end_time_sim:
        factor *= incident.factor
    return max(0.1, min(1.5, factor))


def maybe_spawn_incident(
    sim_time_sec: float,
    incidents: dict[str, TrafficIncident],
    rate_per_hour: float,
    grid_cells: list[str],
    rng: random.Random,
) -> None:
    if not grid_cells:
        return
    prob = rate_per_hour / 3600.0
    if rng.random() < prob:
        cell = rng.choice(grid_cells)
        duration = rng.uniform(10 * 60, 30 * 60)
        factor = rng.uniform(0.2, 0.4)
        incidents[cell] = TrafficIncident(cell=cell, end_time_sim=sim_time_sec + duration, factor=factor)


def current_sim_datetime(sim_start_real: float, sim_time_sec: float) -> str:
    real = sim_start_real + sim_time_sec
    return datetime.fromtimestamp(real, tz=timezone.utc).isoformat()