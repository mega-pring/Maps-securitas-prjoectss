import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from geometry import cumulative_distances, decode_polyline


def test_decode_polyline():
    encoded = '_p~iF~ps|U_ulLnnqC_mqNvxq`@'
    pts = decode_polyline(encoded, precision=5)
    assert len(pts) == 3
    assert abs(pts[0][0] - 38.5) < 1e-5
    assert abs(pts[0][1] + 120.2) < 1e-5


def test_cumulative_distance_monotonic():
    pts = [(0.0, 0.0), (0.0, 0.01), (0.01, 0.01)]
    cum = cumulative_distances(pts)
    assert cum[0] == 0
    assert cum[1] > cum[0]
    assert cum[2] > cum[1]
