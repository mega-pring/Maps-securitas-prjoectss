import math
from typing import Iterable, List, Tuple


def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371000.0
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def decode_polyline(encoded: str, precision: int = 6) -> List[Tuple[float, float]]:
    coords: List[Tuple[float, float]] = []
    index = 0
    lat = 0
    lon = 0
    factor = 10 ** precision

    while index < len(encoded):
        shift = 0
        result = 0
        while True:
            b = ord(encoded[index]) - 63
            index += 1
            result |= (b & 0x1F) << shift
            shift += 5
            if b < 0x20:
                break
        dlat = ~(result >> 1) if result & 1 else result >> 1
        lat += dlat

        shift = 0
        result = 0
        while True:
            b = ord(encoded[index]) - 63
            index += 1
            result |= (b & 0x1F) << shift
            shift += 5
            if b < 0x20:
                break
        dlon = ~(result >> 1) if result & 1 else result >> 1
        lon += dlon

        coords.append((lat / factor, lon / factor))

    return coords


def cumulative_distances(points: Iterable[Tuple[float, float]]) -> List[float]:
    pts = list(points)
    if not pts:
        return []
    cum = [0.0]
    for i in range(1, len(pts)):
        cum.append(cum[-1] + haversine_m(pts[i - 1][0], pts[i - 1][1], pts[i][0], pts[i][1]))
    return cum


def interpolate_position(points: List[Tuple[float, float]], cum_dist: List[float], dist_m: float) -> Tuple[float, float]:
    if not points:
        return (0.0, 0.0)
    if dist_m <= 0:
        return points[0]
    if dist_m >= cum_dist[-1]:
        return points[-1]
    for i in range(1, len(cum_dist)):
        if dist_m <= cum_dist[i]:
            prev_d = cum_dist[i - 1]
            seg_d = cum_dist[i] - prev_d
            if seg_d <= 0:
                return points[i]
            t = (dist_m - prev_d) / seg_d
            lat = points[i - 1][0] + (points[i][0] - points[i - 1][0]) * t
            lon = points[i - 1][1] + (points[i][1] - points[i - 1][1]) * t
            return (lat, lon)
    return points[-1]


def heading_deg(p1: Tuple[float, float], p2: Tuple[float, float]) -> float:
    lat1 = math.radians(p1[0])
    lat2 = math.radians(p2[0])
    dlon = math.radians(p2[1] - p1[1])
    y = math.sin(dlon) * math.cos(lat2)
    x = math.cos(lat1) * math.sin(lat2) - math.sin(lat1) * math.cos(lat2) * math.cos(dlon)
    bearing = math.degrees(math.atan2(y, x))
    return (bearing + 360) % 360