import os
import random
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Dict, List, Tuple

import httpx

from geometry import cumulative_distances, decode_polyline, heading_deg, haversine_m, interpolate_position
from traffic import current_sim_datetime, grid_cell, maybe_spawn_incident, traffic_factor

API_URL = os.getenv("API_URL", "http://dispatch-api:8000")
SIM_TIME_SCALE = float(os.getenv("SIM_TIME_SCALE", "10"))
SIM_TICK_SEC = float(os.getenv("SIM_TICK_SEC", "1"))
SIM_VEHICLES = int(os.getenv("SIM_VEHICLES", "1"))
SIM_CALL_RATE_PER_VEH_PER_DAY = float(os.getenv("SIM_CALL_RATE_PER_VEH_PER_DAY", "2.5"))
SIM_INCIDENT_RATE_PER_HOUR = float(os.getenv("SIM_INCIDENT_RATE_PER_HOUR", "6"))
SIM_SEED = int(os.getenv("SIM_SEED", "42"))
GRID_KM = float(os.getenv("GRID_KM", "1.0"))

HEL_BBOX = {
    "min_lat": 60.13,
    "max_lat": 60.25,
    "min_lon": 24.84,
    "max_lon": 25.05,
}


@dataclass
class RouteState:
    points: List[Tuple[float, float]]
    cum_dist: List[float]
    dist_m: float = 0.0


@dataclass
class VehicleState:
    vehicle_id: str
    mode: str
    status: str
    route: RouteState | None
    last_pt: Tuple[float, float]
    next_patrol_index: int = 0
    active_call_id: str | None = None
    patrol_len: int = 0


class Simulator:
    def __init__(self) -> None:
        self.rng = random.Random(SIM_SEED)
        self.client = httpx.Client(timeout=10)
        self.vehicles: Dict[str, VehicleState] = {}
        self.incidents: Dict[str, any] = {}
        self.grid_cells: List[str] = []
        self.sim_start_real = time.time()
        self.sim_time = 0.0

    def rand_point(self) -> Tuple[float, float]:
        return (
            self.rng.uniform(HEL_BBOX["min_lat"], HEL_BBOX["max_lat"]),
            self.rng.uniform(HEL_BBOX["min_lon"], HEL_BBOX["max_lon"]),
        )

    def register_vehicle(self) -> None:
        vid = "veh-001"
        self.client.post(f"{API_URL}/vehicles/register", json={"vehicle_id": vid, "mode": "PATROL_FUEL"})
        start = self.rand_point()
        self.client.post(
            f"{API_URL}/vehicles/{vid}/location",
            json={
                "lat": start[0],
                "lon": start[1],
                "speed_mps": 0,
                "heading": 0,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        )
        self.vehicles[vid] = VehicleState(
            vehicle_id=vid,
            mode="PATROL_FUEL",
            status="PATROLLING",
            route=None,
            last_pt=start,
            next_patrol_index=0,
            patrol_len=0,
        )
        cell = grid_cell(start[0], start[1], GRID_KM)
        if cell not in self.grid_cells:
            self.grid_cells.append(cell)

    def get_route_geometry(self, vehicle_id: str) -> RouteState | None:
        r = self.client.get(f"{API_URL}/vehicles/{vehicle_id}/route")
        if r.status_code != 200:
            return None
        data = r.json()
        shape = data.get("shape")
        points: List[Tuple[float, float]] = []
        if isinstance(shape, str):
            points = decode_polyline(shape, precision=6)
        elif isinstance(shape, list):
            points = [(p[0], p[1]) for p in shape]
        if len(points) < 2:
            return None
        return RouteState(points=points, cum_dist=cumulative_distances(points))

    def ensure_patrol_route(self, v: VehicleState) -> None:
        self.client.get(f"{API_URL}/vehicles/{v.vehicle_id}/patrol/route")
        v.route = self.get_route_geometry(v.vehicle_id)

    def tick_vehicle(self, v: VehicleState) -> None:
        if not v.route:
            if v.status in {"PATROLLING", "RETURNING"}:
                self.ensure_patrol_route(v)
            elif v.status == "EMERGENCY":
                v.route = self.get_route_geometry(v.vehicle_id)
            if not v.route:
                return

        sim_ts = self.sim_time
        cell = grid_cell(v.last_pt[0], v.last_pt[1], GRID_KM)
        base = 1.0
        daily_amp = 0.15
        noise = 0.05
        factor = traffic_factor(cell, sim_ts, base, daily_amp, noise, self.incidents)
        driver_var = self.rng.uniform(0.9, 1.1)
        if v.status == "EMERGENCY":
            base_speed = self.rng.uniform(11, 18)
        else:
            base_speed = self.rng.uniform(8, 13)
        speed = base_speed * factor * driver_var
        v.route.dist_m += speed * SIM_TICK_SEC * SIM_TIME_SCALE

        new_pt = interpolate_position(v.route.points, v.route.cum_dist, v.route.dist_m)
        head = heading_deg(v.last_pt, new_pt)
        v.last_pt = new_pt

        ts = current_sim_datetime(self.sim_start_real, self.sim_time)
        self.client.post(
            f"{API_URL}/vehicles/{v.vehicle_id}/location",
            json={
                "lat": new_pt[0],
                "lon": new_pt[1],
                "speed_mps": speed,
                "heading": head,
                "timestamp": ts,
            },
        )

        if v.route.dist_m >= v.route.cum_dist[-1] - 1.0:
            v.route = None
            if v.status == "PATROLLING":
                if v.patrol_len > 0:
                    v.next_patrol_index = (v.next_patrol_index + 1) % v.patrol_len
                    self.client.post(
                        f"{API_URL}/vehicles/{v.vehicle_id}/patrol/advance",
                        json={"next_patrol_index": v.next_patrol_index},
                    )
            if v.status == "EMERGENCY":
                v.status = "ON_SCENE"
                self.client.post(f"{API_URL}/vehicles/{v.vehicle_id}/status", json={"status": "ON_SCENE"})
            if v.status == "RETURNING":
                v.status = "PATROLLING"
                self.client.post(f"{API_URL}/vehicles/{v.vehicle_id}/status", json={"status": "PATROLLING"})

    def sync_patrol_length(self, v: VehicleState) -> None:
        r = self.client.get(f"{API_URL}/telemetry/patrol/{v.vehicle_id}")
        if r.status_code == 200:
            data = r.json()
            v.patrol_len = len(data.get("points", []))

    def sync_vehicle_state(self, v: VehicleState) -> None:
        r = self.client.get(f"{API_URL}/telemetry/vehicle/{v.vehicle_id}")
        if r.status_code == 200:
            data = r.json()
            v.status = data.get("status", v.status)
            v.mode = data.get("mode", v.mode)

    def run(self) -> None:
        self.register_vehicle()
        while True:
            maybe_spawn_incident(self.sim_time, self.incidents, SIM_INCIDENT_RATE_PER_HOUR, self.grid_cells, self.rng)
            for v in self.vehicles.values():
                self.sync_patrol_length(v)
                self.sync_vehicle_state(v)
                self.tick_vehicle(v)
            self.sim_time += SIM_TICK_SEC * SIM_TIME_SCALE
            time.sleep(SIM_TICK_SEC)


def main() -> None:
    sim = Simulator()
    sim.run()


if __name__ == "__main__":
    main()
