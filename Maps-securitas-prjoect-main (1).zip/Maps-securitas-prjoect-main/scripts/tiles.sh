#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="$ROOT_DIR/.env"
if [ -f "$ENV_FILE" ]; then
  set -a
  # shellcheck disable=SC1090
  source "$ENV_FILE"
  set +a
fi

PBF_URL="${PBF_URL:-https://download.bbbike.org/osm/bbbike/Helsinki/Helsinki.osm.pbf}"
PBF_FILE="${PBF_FILE:-Helsinki.osm.pbf}"

mkdir -p "$ROOT_DIR/data/pbf" "$ROOT_DIR/data/valhalla"
PBF_PATH="$ROOT_DIR/data/pbf/$PBF_FILE"

if [ ! -f "$PBF_PATH" ]; then
  echo "Downloading PBF: $PBF_URL"
  curl -L "$PBF_URL" -o "$PBF_PATH"
fi

docker run --rm \
  -v "$ROOT_DIR/data/valhalla:/custom_files" \
  -v "$ROOT_DIR/data/pbf:/data" \
  ghcr.io/valhalla/valhalla:latest \
  bash -lc "set -euo pipefail; \
    valhalla_build_config --mjolnir-tile-dir /custom_files/tiles --mjolnir-admin /custom_files/admins.sqlite --mjolnir-timezone /custom_files/timezone.sqlite > /custom_files/valhalla.json; \
    valhalla_build_admins -c /custom_files/valhalla.json /data/$PBF_FILE; \
    valhalla_build_timezones -c /custom_files/valhalla.json; \
    valhalla_build_tiles -c /custom_files/valhalla.json /data/$PBF_FILE"