param(
  [string]$PbfUrl = $env:PBF_URL,
  [string]$PbfFile = $env:PBF_FILE
)

$root = Split-Path -Parent $PSScriptRoot
$envFile = Join-Path $root ".env"
if (Test-Path $envFile) {
  Get-Content $envFile | ForEach-Object {
    if ($_ -match '^(\w+)=(.*)$') {
      $name = $matches[1]
      $value = $matches[2]
      [Environment]::SetEnvironmentVariable($name, $value)
    }
  }
}

if (-not $PbfUrl) { $PbfUrl = "https://download.bbbike.org/osm/bbbike/Helsinki/Helsinki.osm.pbf" }
if (-not $PbfFile) { $PbfFile = "Helsinki.osm.pbf" }

$dataPbf = Join-Path $root "data\pbf"
$dataValhalla = Join-Path $root "data\valhalla"
New-Item -ItemType Directory -Force -Path $dataPbf | Out-Null
New-Item -ItemType Directory -Force -Path $dataValhalla | Out-Null

$pbfPath = Join-Path $dataPbf $PbfFile
if (-not (Test-Path $pbfPath)) {
  Write-Host "Downloading PBF: $PbfUrl"
  Invoke-WebRequest -Uri $PbfUrl -OutFile $pbfPath
}

function ToDockerPath([string]$path) {
  $full = (Resolve-Path $path).Path
  if ($full -match "^[A-Za-z]:\\") {
    $drive = $full.Substring(0,1).ToLower()
    $rest = $full.Substring(2).Replace('\','/')
    return "/$drive$rest"
  }
  return $full.Replace('\','/')
}

$valhallaMount = ToDockerPath $dataValhalla
$pbfMount = ToDockerPath $dataPbf

$dockerCmd = @(
  "docker", "run", "--rm",
  "-v", "${valhallaMount}:/custom_files",
  "-v", "${pbfMount}:/data",
  "ghcr.io/valhalla/valhalla:latest",
  "bash", "-lc",
  "set -euo pipefail; " +
  "valhalla_build_config --mjolnir-tile-dir /custom_files/tiles --mjolnir-admin /custom_files/admins.sqlite --mjolnir-timezone /custom_files/timezone.sqlite > /custom_files/valhalla.json; " +
  "valhalla_build_admins -c /custom_files/valhalla.json /data/$PbfFile; " +
  "valhalla_build_timezones -c /custom_files/valhalla.json; " +
  "valhalla_build_tiles -c /custom_files/valhalla.json /data/$PbfFile"
)

Write-Host "Building tiles..."
& $dockerCmd[0] @($dockerCmd[1..($dockerCmd.Length - 1)])
